CREATE DATABASE IF NOT EXISTS studymate DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE studymate;

CREATE TABLE IF NOT EXISTS user (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    nickname VARCHAR(100) NOT NULL DEFAULT '默认用户',
    avatar VARCHAR(255) DEFAULT '',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS chat_history (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT NOT NULL,
    user_message TEXT NOT NULL,
    ai_response TEXT NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user_id (user_id),
    INDEX idx_created_at (created_at),
    FOREIGN KEY (user_id) REFERENCES user(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS document (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT NOT NULL,
    file_name VARCHAR(255) NOT NULL,
    file_type VARCHAR(20) NOT NULL,
    file_size BIGINT NOT NULL,
    content LONGTEXT,
    summary TEXT,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_user_id (user_id),
    INDEX idx_created_at (created_at),
    FOREIGN KEY (user_id) REFERENCES user(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS link_map (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    scene_type VARCHAR(50) NOT NULL,
    scene_name VARCHAR(100) NOT NULL,
    link_url VARCHAR(500) NOT NULL,
    link_name VARCHAR(200) NOT NULL,
    description VARCHAR(500),
    sort_order INT DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_scene_type (scene_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO link_map (scene_type, scene_name, link_url, link_name, description, sort_order) VALUES
('leave', 'Leave', 'http://oa.example.com/leave', 'Leave Application', 'Submit leave application online', 1),
('leave', 'Leave', 'http://hr.example.com/policy/leave', 'Leave Policy', 'Company leave policy and procedures', 2),
('reimburse', 'Reimburse', 'http://oa.example.com/reimburse', 'Reimburse Application', 'Submit expense reimbursement', 1),
('reimburse', 'Reimburse', 'http://finance.example.com/policy/reimburse', 'Reimburse Policy', 'Reimbursement standards and procedures', 2),
('course', 'Course', 'http://edu.example.com/course', 'Course Selection', 'Online course selection system', 1),
('course', 'Course', 'http://edu.example.com/policy/course', 'Course Guide', 'Course selection rules and schedule', 2),
('subsidy', 'Subsidy', 'http://student.example.com/subsidy', 'Subsidy Application', 'Scholarship and grant application', 1),
('subsidy', 'Subsidy', 'http://student.example.com/policy/subsidy', 'Subsidy Policy', 'Subsidy eligibility and procedures', 2);
