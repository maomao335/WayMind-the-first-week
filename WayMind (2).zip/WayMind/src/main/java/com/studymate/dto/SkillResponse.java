package com.studymate.dto;

import lombok.Data;

import java.util.List;

@Data
public class SkillResponse {

    private String result;

    private String sceneType;

    private String sceneName;

    private List<LinkInfo> links;

    private DocumentInfo document;

    @Data
    public static class LinkInfo {
        private String name;
        private String url;
        private String description;
    }

    @Data
    public static class DocumentInfo {
        private Long id;
        private String fileName;
        private String fileType;
        private Long fileSize;
        private String content;
        private String summary;
    }
}