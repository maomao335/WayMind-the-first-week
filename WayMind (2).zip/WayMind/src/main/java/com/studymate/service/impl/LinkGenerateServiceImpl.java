package com.studymate.service.impl;

import com.studymate.dto.SkillResponse;
import com.studymate.entity.LinkMap;
import com.studymate.mapper.LinkMapMapper;
import com.studymate.service.LinkGenerateService;
import com.studymate.util.IntentRecognizerUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class LinkGenerateServiceImpl implements LinkGenerateService {

    @Autowired
    private IntentRecognizerUtil intentRecognizerUtil;

    @Autowired
    private LinkMapMapper linkMapMapper;

    @Override
    public SkillResponse generateLinks(Long userId, String message) {
        if (message == null || message.trim().isEmpty()) {
            throw new IllegalArgumentException("Message cannot be empty");
        }

        IntentRecognizerUtil.SceneType sceneType = intentRecognizerUtil.recognize(message);
        String sceneCode = sceneType.getCode();

        List<LinkMap> linkMaps = linkMapMapper.selectBySceneType(sceneCode);

        List<SkillResponse.LinkInfo> links = new ArrayList<>();
        for (LinkMap linkMap : linkMaps) {
            SkillResponse.LinkInfo linkInfo = new SkillResponse.LinkInfo();
            linkInfo.setName(linkMap.getLinkName());
            linkInfo.setUrl(linkMap.getLinkUrl());
            linkInfo.setDescription(linkMap.getDescription());
            links.add(linkInfo);
        }

        SkillResponse response = new SkillResponse();
        response.setSceneType(sceneCode);
        response.setSceneName(sceneType.getName());
        response.setLinks(links);

        if (links.isEmpty()) {
            response.setResult("暂无相关办事链接");
        } else {
            response.setResult("已为您找到相关办事链接");
        }

        return response;
    }
}