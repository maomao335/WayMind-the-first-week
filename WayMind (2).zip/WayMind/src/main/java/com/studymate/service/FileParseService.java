package com.studymate.service;

import com.studymate.dto.SkillResponse;
import org.springframework.web.multipart.MultipartFile;

public interface FileParseService {

    SkillResponse parseFile(Long userId, MultipartFile file);
}