package com.studymate.service;

import com.studymate.dto.SkillResponse;

public interface LinkGenerateService {

    SkillResponse generateLinks(Long userId, String message);
}