package com.studymate.service.impl;

import com.studymate.dto.SkillResponse;
import com.studymate.service.DialogClarifyService;
import com.studymate.util.IntentRecognizerUtil;
import com.studymate.util.QianWenClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;

@Service
public class DialogClarifyServiceImpl implements DialogClarifyService {

    @Autowired
    private IntentRecognizerUtil intentRecognizerUtil;

    @Autowired
    private QianWenClient qianWenClient;

    @Override
    public SkillResponse clarify(Long userId, String message) {
        if (message == null || message.trim().isEmpty()) {
            throw new IllegalArgumentException("Message cannot be empty");
        }

        IntentRecognizerUtil.SceneType sceneType = intentRecognizerUtil.recognize(message);

        String clarifyPrompt = buildClarifyPrompt(message, sceneType);
        String aiResponse;

        try {
            aiResponse = qianWenClient.chat(clarifyPrompt);
        } catch (IOException e) {
            throw new RuntimeException("Failed to call QianWen API", e);
        }

        SkillResponse response = new SkillResponse();
        response.setResult(aiResponse);
        response.setSceneType(sceneType.getCode());
        response.setSceneName(sceneType.getName());

        return response;
    }

    private String buildClarifyPrompt(String message, IntentRecognizerUtil.SceneType sceneType) {
        String scenePrompt;
        switch (sceneType) {
            case LEAVE:
                scenePrompt = "这是一个请假相关的问题，请询问用户以下信息：请假类型（事假/病假/年假等）、请假时间（开始日期、结束日期）、请假原因。";
                break;
            case REIMBURSE:
                scenePrompt = "这是一个报销相关的问题，请询问用户以下信息：报销类型（差旅/办公用品/其他）、报销金额、报销事由、是否有发票。";
                break;
            case COURSE:
                scenePrompt = "这是一个选课相关的问题，请询问用户以下信息：所在年级/专业、意向课程类型、时间安排偏好。";
                break;
            case SUBSIDY:
                scenePrompt = "这是一个补助相关的问题，请询问用户以下信息：补助类型（助学金/奖学金/生活补助）、申请条件是否满足、是否已准备相关材料。";
                break;
            default:
                scenePrompt = "这是一个通用问题，请询问用户需要了解的具体信息。";
        }

        return String.format("用户说：\"%s\"。%s 请用友好、简洁的方式向用户提问，获取必要信息以便更好地帮助用户。", message, scenePrompt);
    }
}