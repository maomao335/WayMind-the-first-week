package com.studymate.service;

import com.studymate.dto.SkillResponse;

public interface DialogClarifyService {

    SkillResponse clarify(Long userId, String message);
}