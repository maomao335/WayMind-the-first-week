package com.studymate.controller;

import com.studymate.dto.ApiResponse;
import com.studymate.dto.SkillResponse;
import com.studymate.service.DialogClarifyService;
import com.studymate.service.FileParseService;
import com.studymate.service.LinkGenerateService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/api/skill")
public class SkillController {

    @Autowired
    private FileParseService fileParseService;

    @Autowired
    private DialogClarifyService dialogClarifyService;

    @Autowired
    private LinkGenerateService linkGenerateService;

    @PostMapping("/file-parse")
    public ApiResponse<SkillResponse> parseFile(
            @RequestParam(value = "userId", required = false) Long userId,
            @RequestParam("file") MultipartFile file) {
        SkillResponse response = fileParseService.parseFile(userId, file);
        return ApiResponse.success(response);
    }

    @PostMapping("/dialog-clarify")
    public ApiResponse<SkillResponse> clarify(
            @RequestParam(value = "userId", required = false) Long userId,
            @RequestParam("message") String message) {
        SkillResponse response = dialogClarifyService.clarify(userId, message);
        return ApiResponse.success(response);
    }

    @PostMapping("/link-generate")
    public ApiResponse<SkillResponse> generateLinks(
            @RequestParam(value = "userId", required = false) Long userId,
            @RequestParam("message") String message) {
        SkillResponse response = linkGenerateService.generateLinks(userId, message);
        return ApiResponse.success(response);
    }
}