package com.studymate.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@TableName("link_map")
public class LinkMap {

    @TableId(type = IdType.AUTO)
    private Long id;

    @TableField("scene_type")
    private String sceneType;

    @TableField("scene_name")
    private String sceneName;

    @TableField("link_url")
    private String linkUrl;

    @TableField("link_name")
    private String linkName;

    @TableField("description")
    private String description;

    @TableField("sort_order")
    private Integer sortOrder;

    @TableField("created_at")
    private LocalDateTime createdAt;

    @TableField("updated_at")
    private LocalDateTime updatedAt;
}