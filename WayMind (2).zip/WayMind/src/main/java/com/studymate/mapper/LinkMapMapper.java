package com.studymate.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.studymate.entity.LinkMap;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface LinkMapMapper extends BaseMapper<LinkMap> {

    @Select("SELECT * FROM link_map WHERE scene_type = #{sceneType} ORDER BY sort_order")
    List<LinkMap> selectBySceneType(String sceneType);
}