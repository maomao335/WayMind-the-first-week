package com.studymate.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.studymate.entity.Document;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface DocumentMapper extends BaseMapper<Document> {

    @Select("SELECT * FROM document WHERE user_id = #{userId} ORDER BY created_at DESC")
    List<Document> selectByUserId(Long userId);
}