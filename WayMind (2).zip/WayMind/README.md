# StudyMate v0.2 - 校园/职场RAG智能问答机器人

## 项目阶段说明

### v0.1 版本（第一周）- 基础对话能力

**定位**：最小可运行原型，仅具备基础对话AI能力

实现功能：
- 用户发送文本消息
- 调用通义千问API获取AI回复
- 持久化存储对话历史记录

### v0.2 版本（第二周）- 三大AI Skill能力

**定位**：在基础对话之上，新增三大独立AI Skill能力

新增功能：
- 📁 **文件解析Skill**：支持上传PDF/Word文档，解析内容并生成摘要
- 🔍 **对话澄清Skill**：识别模糊问题，自动追问补充信息，支持多轮对话
- 🔗 **链接生成Skill**：根据场景意图匹配相关办事链接

> **注意**：当前版本不包含RAG检索增强、Agent自动调度、知识库管理面板等高级功能，这些将在第三周v0.3版本中实现。

---

## 环境准备

### 前置依赖

| 依赖项 | 版本要求 | 说明 |
| :--- | :--- | :--- |
| MySQL | 8.0+ | 数据库服务 |
| JDK | 17+（推荐21） | 后端运行环境 |
| Maven | 3.8+ | 项目构建工具 |
| 浏览器 | Chrome/Edge/Firefox | 前端访问 |

### 环境验证

```bash
# 验证JDK版本
java -version

# 验证Maven版本
mvn -v

# 验证MySQL服务状态
mysql -u root -p -e "SELECT VERSION();"
```

---

## 启动流程

### 第一步：创建数据库

使用具有 `CREATE DATABASE` 权限的MySQL账号执行：

```sql
CREATE DATABASE IF NOT EXISTS studymate DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

### 第二步：执行建表SQL

进入项目目录，执行建表脚本：

```bash
# Windows PowerShell
Get-Content -Raw src/main/resources/schema.sql | mysql.exe -u root -p studymate

# Linux/Mac
mysql -u root -p studymate < src/main/resources/schema.sql
```

或手动在MySQL客户端中执行 `src/main/resources/schema.sql` 文件内容。

> **v0.2新增**：脚本会自动创建 `document` 和 `link_map` 两张新表，并插入初始链接数据。

### 第三步：配置密钥

编辑 `src/main/resources/application.yml` 文件：

```yaml
server:
  port: 8080

spring:
  datasource:
    url: jdbc:mysql://localhost:3306/studymate?useUnicode=true&characterEncoding=utf8&serverTimezone=Asia/Shanghai
    username: your-db-username    # 替换为你的数据库用户名
    password: your-db-password    # 替换为你的数据库密码
  servlet:
    multipart:
      max-file-size: 10MB
      max-request-size: 10MB

qianwen:
  api-key: your-qianwen-api-key   # 替换为你的通义千问API Key
```

> **通义千问API Key获取**：访问阿里云DashScope控制台（https://dashscope.console.aliyun.com/）申请API Key。

### 第四步：启动后端服务

```bash
cd StudyMate
mvn spring-boot:run
```

启动成功后，服务将运行在 `http://localhost:8080`。

### 第五步：打开前端页面

直接在浏览器中打开项目根目录下的 `index.html` 文件即可。

---

## 接口说明

### 接口总览

| 接口路径 | HTTP方法 | Content-Type | 说明 |
| :--- | :--- | :--- | :--- |
| `/api/chat/send` | POST | application/json | 基础对话（v0.1） |
| `/api/skill/file-parse` | POST | multipart/form-data | 文件解析（v0.2） |
| `/api/skill/dialog-clarify` | POST | application/x-www-form-urlencoded | 对话澄清（v0.2） |
| `/api/skill/link-generate` | POST | application/x-www-form-urlencoded | 链接生成（v0.2） |

---

### 1. 基础对话接口（v0.1）

**POST** `/api/chat/send`

#### 请求参数

| 参数名 | 类型 | 必填 | 说明 |
| :--- | :--- | :--- | :--- |
| userId | Long | 否 | 用户ID，首次发送可传null，系统会自动创建用户 |
| message | String | 是 | 用户输入的问题文本 |

#### 请求示例

```json
{
    "userId": 1,
    "message": "你好，帮我介绍一下Spring Boot框架"
}
```

#### 响应示例

```json
{
    "code": 200,
    "message": "success",
    "data": {
        "reply": "Spring Boot是由Pivotal团队提供的...",
        "userId": 1
    }
}
```

---

### 2. 文件解析接口（v0.2）

**POST** `/api/skill/file-parse`

#### 请求参数

| 参数名 | 类型 | 必填 | 说明 |
| :--- | :--- | :--- | :--- |
| userId | Long | 否 | 用户ID |
| file | MultipartFile | 是 | 上传的文件（支持PDF/DOC/DOCX，最大10MB） |

#### 请求示例（curl）

```bash
curl -X POST http://localhost:8080/api/skill/file-parse \
  -F "userId=1" \
  -F "file=@example.pdf"
```

#### 响应示例

```json
{
    "code": 200,
    "message": "success",
    "data": {
        "result": "文件解析成功",
        "sceneType": null,
        "sceneName": null,
        "links": null,
        "document": {
            "id": 1,
            "fileName": "example.pdf",
            "fileType": "pdf",
            "fileSize": 102400,
            "content": "文档正文内容...",
            "summary": "文档摘要（前200字）..."
        }
    }
}
```

#### 错误响应示例

```json
{
    "code": 400,
    "message": "Unsupported file type. Only PDF, DOC, DOCX are allowed"
}
```

---

### 3. 对话澄清接口（v0.2）

**POST** `/api/skill/dialog-clarify`

#### 请求参数

| 参数名 | 类型 | 必填 | 说明 |
| :--- | :--- | :--- | :--- |
| userId | Long | 否 | 用户ID |
| message | String | 是 | 用户输入的问题文本 |

#### 请求示例（curl）

```bash
curl -X POST http://localhost:8080/api/skill/dialog-clarify \
  -d "userId=1" \
  -d "message=我想请假"
```

#### 响应示例

```json
{
    "code": 200,
    "message": "success",
    "data": {
        "result": "请问您想请什么类型的假呢？是事假、病假还是年假？另外方便告知请假的具体时间和原因吗？",
        "sceneType": "leave",
        "sceneName": "Leave",
        "links": null,
        "document": null
    }
}
```

#### 场景类型说明

| sceneType | sceneName | 触发关键词 |
| :--- | :--- | :--- |
| leave | Leave | 请假、休假、放假 |
| reimburse | Reimburse | 报销、费用、报销单 |
| course | Course | 选课、课程、上课 |
| subsidy | Subsidy | 补助、助学金、奖学金 |
| other | Other | 其他场景 |

---

### 4. 链接生成接口（v0.2）

**POST** `/api/skill/link-generate`

#### 请求参数

| 参数名 | 类型 | 必填 | 说明 |
| :--- | :--- | :--- | :--- |
| userId | Long | 否 | 用户ID |
| message | String | 是 | 用户输入的问题文本 |

#### 请求示例（curl）

```bash
curl -X POST http://localhost:8080/api/skill/link-generate \
  -d "userId=1" \
  -d "message=我要报销差旅费"
```

#### 响应示例

```json
{
    "code": 200,
    "message": "success",
    "data": {
        "result": "已为您找到相关办事链接",
        "sceneType": "reimburse",
        "sceneName": "Reimburse",
        "links": [
            {
                "name": "Reimburse Application",
                "url": "http://oa.example.com/reimburse",
                "description": "Submit expense reimbursement"
            },
            {
                "name": "Reimburse Policy",
                "url": "http://finance.example.com/policy/reimburse",
                "description": "Reimbursement standards and procedures"
            }
        ],
        "document": null
    }
}
```

---

## 新增功能使用教程

### 1. 文件上传功能

**操作步骤**：

1. 在左侧边栏找到「📁 文件上传」区域
2. **方式一**：点击上传区域，选择本地PDF/DOC/DOCX文件
3. **方式二**：直接将文件拖拽到上传区域
4. 上传过程中会显示进度条
5. 上传完成后，文档会出现在「📄 已上传文档」列表中
6. 点击文档右侧的「×」可删除文档

**注意事项**：
- 仅支持PDF、DOC、DOCX格式
- 单个文件最大10MB
- 文件内容会自动解析并生成摘要

### 2. 多轮追问功能

**操作步骤**：

1. 在聊天框中发送一条模糊问题（如："我想请假"）
2. 点击左侧边栏「🔍 追问澄清」按钮
3. AI会弹出追问弹窗，询问补充信息
4. 在弹窗中输入补充信息后点击「确认」
5. AI继续基于完整信息进行回复
6. 若仍有疑问，会继续追问（支持多轮）

**示例对话流程**：
```
用户：我想请假
AI：请问您想请什么类型的假呢？
用户（弹窗输入）：病假
AI：请问您请假的具体时间是？
用户（弹窗输入）：明天一天
AI：好的，已记录您的病假申请...
```

### 3. 办事链接功能

**操作步骤**：

1. 在聊天框中发送与办事相关的问题（如："怎么报销"）
2. 点击左侧边栏「🔗 办事链接」按钮
3. AI会识别场景意图并返回相关办事链接
4. 在AI回复底部会显示可点击的链接按钮
5. 点击链接会在新窗口中打开

**支持场景**：
- 请假相关 → 返回请假申请、请假政策链接
- 报销相关 → 返回报销申请、报销政策链接
- 选课相关 → 返回选课系统、选课指南链接
- 补助相关 → 返回补助申请、补助政策链接

---

## 新增环境依赖说明

### PDF/Word解析依赖

v0.2版本新增以下Maven依赖用于文件解析：

```xml
<!-- PDF解析 -->
<dependency>
    <groupId>org.apache.pdfbox</groupId>
    <artifactId>pdfbox</artifactId>
    <version>3.0.2</version>
</dependency>

<!-- Word解析（DOC格式） -->
<dependency>
    <groupId>org.apache.poi</groupId>
    <artifactId>poi</artifactId>
    <version>5.2.5</version>
</dependency>

<!-- Word解析（DOCX格式） -->
<dependency>
    <groupId>org.apache.poi</groupId>
    <artifactId>poi-ooxml</artifactId>
    <version>5.2.5</version>
</dependency>

<!-- Word解析（旧版DOC格式支持） -->
<dependency>
    <groupId>org.apache.poi</groupId>
    <artifactId>poi-scratchpad</artifactId>
    <version>5.2.5</version>
</dependency>
```

**依赖说明**：
- `pdfbox`：Apache PDFBox，用于解析PDF文档内容
- `poi`：Apache POI，用于解析传统DOC格式Word文档
- `poi-ooxml`：Apache POI OOXML模块，用于解析DOCX格式Word文档
- `poi-scratchpad`：Apache POI扩展模块，支持旧版二进制DOC格式

---

## 新增数据表说明

### document 表（文档表）

存储用户上传并解析后的文档信息。

| 字段名 | 类型 | 说明 |
| :--- | :--- | :--- |
| id | BIGINT | 主键，自增 |
| user_id | BIGINT | 用户ID（外键关联user表） |
| file_name | VARCHAR(255) | 文件名 |
| file_type | VARCHAR(20) | 文件类型（pdf/doc/docx） |
| file_size | BIGINT | 文件大小（字节） |
| content | LONGTEXT | 解析后的文档内容 |
| summary | TEXT | 文档摘要 |
| created_at | DATETIME | 创建时间 |
| updated_at | DATETIME | 更新时间 |

### link_map 表（链接映射表）

存储场景与办事链接的映射关系。

| 字段名 | 类型 | 说明 |
| :--- | :--- | :--- |
| id | BIGINT | 主键，自增 |
| scene_type | VARCHAR(50) | 场景类型（leave/reimburse/course/subsidy） |
| scene_name | VARCHAR(100) | 场景名称 |
| link_url | VARCHAR(500) | 链接地址 |
| link_name | VARCHAR(200) | 链接名称 |
| description | VARCHAR(500) | 链接描述 |
| sort_order | INT | 排序序号 |
| created_at | DATETIME | 创建时间 |
| updated_at | DATETIME | 更新时间 |

**初始数据**：建表SQL会自动插入8条链接数据，覆盖4个场景（请假、报销、选课、补助），每个场景2条链接。

---

## 版本边界说明

### v0.2已实现功能

| 功能 | 状态 | 说明 |
| :--- | :--- | :--- |
| 基础对话 | ✅ | 调用通义千问API |
| 文件上传 | ✅ | 支持PDF/DOC/DOCX，解析内容和摘要 |
| 文件解析 | ✅ | 使用PDFBox和POI解析文档 |
| 多轮追问 | ✅ | 识别场景后自动追问补充信息 |
| 场景意图识别 | ✅ | 支持4种场景：请假、报销、选课、补助 |
| 办事链接生成 | ✅ | 根据场景匹配相关链接 |
| 文档列表展示 | ✅ | 前端显示已上传文档 |

### v0.2未实现功能（第三周开发）

| 功能 | 状态 | 说明 |
| :--- | :--- | :--- |
| RAG检索增强 | ❌ | 未接入向量知识库检索 |
| Agent自动调度 | ❌ | 无工具调用、任务规划能力 |
| 知识库管理面板 | ❌ | 无文档库增删改查管理界面 |
| 上下文记忆 | ❌ | 对话历史未用于上下文理解 |
| MCP协议 | ❌ | 未实现Model Context Protocol |
| 第三方系统对接 | ❌ | 未对接真实OA/教务系统 |

> **重要提示**：当前三个Skill接口为独立调用模式，用户需要手动触发。第三周将实现Agent自动调度，根据用户问题自动选择合适的Skill执行。

---

## 新增功能测试操作步骤

### 测试一：上传文档

**步骤**：
1. 启动后端服务
2. 打开前端页面
3. 点击左侧边栏「📁 文件上传」区域
4. 选择一个PDF或Word文件（建议小于10MB）
5. 观察上传进度条显示
6. 上传成功后，确认：
   - 文档出现在「📄 已上传文档」列表中
   - 聊天区域显示AI回复，包含文件名、大小和摘要

**预期结果**：文件解析成功，显示文档摘要信息。

### 测试二：模糊提问触发追问

**步骤**：
1. 在聊天框输入模糊问题：`我想请假`
2. 点击「发送」
3. 点击左侧边栏「🔍 追问澄清」按钮
4. 观察弹出追问弹窗
5. 在弹窗输入框中输入：`病假`
6. 点击「确认」
7. 观察AI继续回复

**预期结果**：
- 第一次触发追问弹窗，询问请假类型
- 输入补充信息后，AI继续追问其他信息或给出完整回复
- AI回复中显示场景标签「Leave」

### 测试三：生成办事链接

**步骤**：
1. 在聊天框输入：`我要报销差旅费`
2. 点击「发送」
3. 点击左侧边栏「🔗 办事链接」按钮
4. 观察AI回复底部的链接按钮

**预期结果**：
- AI回复中显示场景标签「Reimburse」
- 底部显示2个可点击的链接按钮（报销申请、报销政策）
- 点击链接能在新窗口打开

### 测试四：不同场景验证

**测试用例**：

| 输入问题 | 预期场景 | 预期链接数量 |
| :--- | :--- | :--- |
| `我想请年假` | Leave | 2 |
| `怎么报销办公用品` | Reimburse | 2 |
| `如何选选修课` | Course | 2 |
| `申请助学金` | Subsidy | 2 |
| `今天天气怎么样` | Other | 0 |

---

## 常见报错排查

### 1. 数据库连接失败

**报错信息**：
```
Unable to acquire JDBC Connection
```

**排查方案**：
- 确认MySQL服务已启动：`net start mysql`（Windows）或 `systemctl start mysql`（Linux）
- 确认 `application.yml` 中数据库用户名和密码正确
- 确认MySQL端口为3306，或修改yml中端口配置
- 确认数据库 `studymate` 已创建

### 2. API Key错误

**报错信息**：
```
Failed to get response from QianWen API
```

**排查方案**：
- 确认 `application.yml` 中 `qianwen.api-key` 配置正确
- 登录阿里云控制台确认API Key有效且未过期
- 确认账户余额充足（通义千问API按量计费）

### 3. 前端无法发送消息

**报错信息**：
```
网络连接失败，请检查后端服务是否启动
```

**排查方案**：
- 确认后端服务已启动在 `localhost:8080`
- 确认浏览器控制台无CORS错误
- 尝试在浏览器中访问 `http://localhost:8080/api/chat/send` 验证服务状态

### 4. 文件上传失败

**报错信息**：
```
File size exceeds 10MB limit
```
或
```
Unsupported file type. Only PDF, DOC, DOCX are allowed
```

**排查方案**：
- 确认文件格式为PDF/DOC/DOCX
- 确认文件大小不超过10MB
- 检查后端 `application.yml` 中 `max-file-size` 配置

### 5. Maven依赖下载失败

**报错信息**：
```
Could not resolve dependencies
```

**排查方案**：
- 检查网络连接
- 配置国内Maven镜像（在 `~/.m2/settings.xml` 中配置阿里云镜像）
- 清理Maven缓存：`mvn clean install -U`

---

## 项目结构

```
StudyMate/
├── index.html                            # 前端聊天页面（v0.2更新）
├── pom.xml                               # Maven依赖配置（新增文件解析依赖）
├── README.md                             # 项目说明文档
└── src/main/
    ├── java/com/studymate/
    │   ├── Application.java              # 启动类
    │   ├── config/
    │   │   └── CorsConfig.java           # CORS跨域配置
    │   ├── controller/
    │   │   ├── ChatController.java       # 基础对话控制器（v0.1）
    │   │   └── SkillController.java      # Skill接口控制器（v0.2新增）
    │   ├── dto/
    │   │   ├── ApiResponse.java
    │   │   ├── ChatRequest.java
    │   │   ├── ChatResponse.java
    │   │   └── SkillResponse.java        # Skill响应DTO（v0.2新增）
    │   ├── entity/
    │   │   ├── ChatHistory.java
    │   │   ├── User.java
    │   │   ├── Document.java             # 文档实体（v0.2新增）
    │   │   └── LinkMap.java              # 链接映射实体（v0.2新增）
    │   ├── exception/
    │   │   └── GlobalExceptionHandler.java
    │   ├── mapper/
    │   │   ├── ChatHistoryMapper.java
    │   │   ├── UserMapper.java
    │   │   ├── DocumentMapper.java       # 文档Mapper（v0.2新增）
    │   │   └── LinkMapMapper.java        # 链接映射Mapper（v0.2新增）
    │   ├── service/
    │   │   ├── ChatService.java
    │   │   ├── impl/ChatServiceImpl.java
    │   │   ├── FileParseService.java     # 文件解析服务接口（v0.2新增）
    │   │   ├── DialogClarifyService.java # 对话澄清服务接口（v0.2新增）
    │   │   ├── LinkGenerateService.java  # 链接生成服务接口（v0.2新增）
    │   │   └── impl/
    │   │       ├── FileParseServiceImpl.java    # 文件解析实现（v0.2新增）
    │   │       ├── DialogClarifyServiceImpl.java # 对话澄清实现（v0.2新增）
    │   │       └── LinkGenerateServiceImpl.java  # 链接生成实现（v0.2新增）
    │   └── util/
    │       ├── QianWenClient.java        # 通义千问调用工具类
    │       ├── DocumentParserUtil.java   # 文件解析工具类（v0.2新增）
    │       └── IntentRecognizerUtil.java # 场景意图识别工具类（v0.2新增）
    └── resources/
        ├── application.yml               # 应用配置（新增文件上传配置）
        └── schema.sql                    # 建表SQL（新增document和link_map表）
```

---

## 技术栈

| 组件 | 版本 | 说明 |
| :--- | :--- | :--- |
| Spring Boot | 3.2.5 | 后端框架 |
| MyBatis-Plus | 3.5.5 | ORM框架 |
| MySQL | 8.0+ | 数据库 |
| Vue.js | 3.x | 前端框架 |
| Apache HttpClient5 | 5.2.1 | HTTP请求工具 |
| Apache PDFBox | 3.0.2 | PDF解析 |
| Apache POI | 5.2.5 | Word解析 |
| 通义千问 | qwen-turbo | AI大模型 |

---

## License

MIT License