package com.studymate.controller;

import com.studymate.dto.ApiResponse;
import com.studymate.entity.Conversation;
import com.studymate.entity.ChatHistory;
import com.studymate.service.ConversationService;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/conversation")
public class ConversationController {

    @Autowired
    private ConversationService conversationService;

    private Long getUserId(HttpServletRequest request) {
        return (Long) request.getAttribute("userId");
    }

    @PostMapping
    public ApiResponse<Conversation> createConversation(HttpServletRequest request) {
        Long userId = getUserId(request);
        try {
            Conversation conversation = conversationService.createConversation(userId);
            return ApiResponse.success(conversation);
        } catch (Exception e) {
            return ApiResponse.error(500, "创建会话失败：" + e.getMessage());
        }
    }

    @GetMapping
    public ApiResponse<List<Conversation>> listConversations(HttpServletRequest request) {
        Long userId = getUserId(request);
        try {
            List<Conversation> conversations = conversationService.listConversations(userId);
            return ApiResponse.success(conversations);
        } catch (Exception e) {
            return ApiResponse.error(500, "获取会话列表失败：" + e.getMessage());
        }
    }

    @GetMapping("/{id}")
    public ApiResponse<Conversation> getConversation(@PathVariable Long id, HttpServletRequest request) {
        Long userId = getUserId(request);
        try {
            Conversation conversation = conversationService.getConversation(id, userId);
            if (conversation == null) {
                return ApiResponse.error(404, "会话不存在或无权访问");
            }
            return ApiResponse.success(conversation);
        } catch (Exception e) {
            return ApiResponse.error(500, "获取会话失败：" + e.getMessage());
        }
    }

    @GetMapping("/{id}/messages")
    public ApiResponse<List<ChatHistory>> getConversationMessages(@PathVariable Long id, HttpServletRequest request) {
        Long userId = getUserId(request);
        try {
            List<ChatHistory> messages = conversationService.getConversationMessages(id, userId);
            return ApiResponse.success(messages);
        } catch (Exception e) {
            return ApiResponse.error(500, "获取消息列表失败：" + e.getMessage());
        }
    }

    @PutMapping("/{id}/title")
    public ApiResponse<Conversation> updateTitle(
            @PathVariable Long id,
            @RequestBody Map<String, String> body,
            HttpServletRequest request) {
        Long userId = getUserId(request);
        String title = body.get("title");
        if (title == null || title.trim().isEmpty()) {
            return ApiResponse.error(400, "标题不能为空");
        }
        try {
            Conversation conversation = conversationService.updateTitle(id, userId, title);
            return ApiResponse.success(conversation);
        } catch (IllegalArgumentException e) {
            return ApiResponse.error(404, e.getMessage());
        } catch (Exception e) {
            return ApiResponse.error(500, "更新标题失败：" + e.getMessage());
        }
    }

    @DeleteMapping("/{id}")
    public ApiResponse<Void> deleteConversation(@PathVariable Long id, HttpServletRequest request) {
        Long userId = getUserId(request);
        try {
            conversationService.deleteConversation(id, userId);
            return ApiResponse.success(null);
        } catch (IllegalArgumentException e) {
            return ApiResponse.error(404, e.getMessage());
        } catch (Exception e) {
            return ApiResponse.error(500, "删除会话失败：" + e.getMessage());
        }
    }
}