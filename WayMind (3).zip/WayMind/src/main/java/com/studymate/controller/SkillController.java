package com.studymate.controller;

import com.studymate.dto.ApiResponse;
import com.studymate.dto.SkillResponse;
import com.studymate.entity.Document;
import com.studymate.mapper.DocumentMapper;
import com.studymate.rag.service.DocumentVectorService;
import com.studymate.service.DialogClarifyService;
import com.studymate.service.FileParseService;
import com.studymate.service.LinkGenerateService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import jakarta.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/skill")
public class SkillController {

    @Autowired
    private FileParseService fileParseService;

    @Autowired
    private DialogClarifyService dialogClarifyService;

    @Autowired
    private LinkGenerateService linkGenerateService;

    @Autowired
    private DocumentMapper documentMapper;

    @Autowired
    private DocumentVectorService documentVectorService;

    @PostMapping("/file-parse")
    public ApiResponse<SkillResponse> parseFile(
            @RequestParam(value = "userId", required = false) Long userId,
            @RequestParam("file") MultipartFile file,
            HttpServletRequest httpRequest) {
        Long authUserId = (Long) httpRequest.getAttribute("userId");
        if (authUserId != null) {
            userId = authUserId;
        }
        SkillResponse response = fileParseService.parseFile(userId, file);
        return ApiResponse.success(response);
    }

    @PostMapping("/dialog-clarify")
    public ApiResponse<SkillResponse> clarify(
            @RequestParam(value = "userId", required = false) Long userId,
            @RequestParam("message") String message) {
        SkillResponse response = dialogClarifyService.clarify(userId, message);
        return ApiResponse.success(response);
    }

    @PostMapping("/link-generate")
    public ApiResponse<SkillResponse> generateLinks(
            @RequestParam(value = "userId", required = false) Long userId,
            @RequestParam("message") String message) {
        SkillResponse response = linkGenerateService.generateLinks(userId, message);
        return ApiResponse.success(response);
    }

    @GetMapping("/document/list")
    public ApiResponse<List<Map<String, Object>>> listDocuments(
            @RequestParam(required = false) Long userId) {
        List<Document> documents;
        if (userId != null) {
            documents = documentMapper.selectByUserId(userId);
        } else {
            documents = documentMapper.selectList(null);
        }

        List<Map<String, Object>> result = new java.util.ArrayList<>();
        for (Document doc : documents) {
            Map<String, Object> docMap = new HashMap<>();
            docMap.put("id", doc.getId());
            docMap.put("fileName", doc.getFileName());
            docMap.put("fileType", doc.getFileType());
            docMap.put("fileSize", doc.getFileSize());
            docMap.put("createdAt", doc.getCreatedAt());
            
            int vectorCount = documentVectorService.countByDocumentId(doc.getId());
            docMap.put("vectorCount", vectorCount);
            docMap.put("vectorized", vectorCount > 0);
            
            result.add(docMap);
        }

        return ApiResponse.success(result);
    }

    @DeleteMapping("/document/{id}")
    public ApiResponse<Void> deleteDocument(@PathVariable Long id) {
        documentVectorService.deleteByDocumentId(id);
        documentMapper.deleteById(id);
        return ApiResponse.success(null);
    }

    @DeleteMapping("/document/all")
    public ApiResponse<Void> deleteAllDocuments(
            @RequestParam(required = false) Long userId) {
        List<Document> documents;
        if (userId != null) {
            documents = documentMapper.selectByUserId(userId);
        } else {
            documents = documentMapper.selectList(null);
        }

        for (Document doc : documents) {
            documentVectorService.deleteByDocumentId(doc.getId());
            documentMapper.deleteById(doc.getId());
        }

        return ApiResponse.success(null);
    }
}