package com.studymate.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

@Component
public class DatabaseMigrationRunner implements ApplicationRunner {

    private static final Logger log = LoggerFactory.getLogger(DatabaseMigrationRunner.class);

    @Autowired
    private DataSource dataSource;

    @Override
    public void run(ApplicationArguments args) throws Exception {
        migrateDatabase();
    }

    private void migrateDatabase() {
        try (Connection conn = dataSource.getConnection()) {
            boolean needsRebuild = false;
            try {
                try (Statement stmt = conn.createStatement();
                     ResultSet rs = stmt.executeQuery("SELECT username FROM user LIMIT 1")) {
                }
            } catch (SQLException e) {
                needsRebuild = true;
            }
            
            if (needsRebuild) {
                log.info("Rebuilding all tables...");
                try (Statement stmt = conn.createStatement()) {
                    stmt.execute("DROP TABLE IF EXISTS chat_history");
                    stmt.execute("DROP TABLE IF EXISTS conversation");
                    stmt.execute("DROP TABLE IF EXISTS document_vector");
                    stmt.execute("DROP TABLE IF EXISTS document");
                    stmt.execute("DROP TABLE IF EXISTS agent_task_log");
                    stmt.execute("DROP TABLE IF EXISTS link_map");
                    stmt.execute("DROP TABLE IF EXISTS user");
                    
                    stmt.execute("CREATE TABLE user (" +
                            "id BIGINT AUTO_INCREMENT PRIMARY KEY, " +
                            "username VARCHAR(100) NOT NULL UNIQUE, " +
                            "password VARCHAR(500) NOT NULL, " +
                            "nickname VARCHAR(100) NOT NULL DEFAULT '默认用户', " +
                            "avatar VARCHAR(255) DEFAULT '', " +
                            "token_expire_time DATETIME DEFAULT NULL, " +
                            "created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, " +
                            "updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, " +
                            "INDEX idx_username (username), " +
                            "INDEX idx_created_at (created_at)" +
                            ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
                    
                    stmt.execute("CREATE TABLE conversation (" +
                            "id BIGINT AUTO_INCREMENT PRIMARY KEY, " +
                            "user_id BIGINT NOT NULL, " +
                            "title VARCHAR(200) NOT NULL DEFAULT '新对话', " +
                            "session_id VARCHAR(100), " +
                            "created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, " +
                            "updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, " +
                            "INDEX idx_user_id (user_id), " +
                            "INDEX idx_updated_at (updated_at), " +
                            "FOREIGN KEY (user_id) REFERENCES user(id) ON DELETE CASCADE" +
                            ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
                    
                    stmt.execute("CREATE TABLE chat_history (" +
                            "id BIGINT AUTO_INCREMENT PRIMARY KEY, " +
                            "user_id BIGINT NOT NULL, " +
                            "conversation_id BIGINT NOT NULL, " +
                            "role VARCHAR(20) NOT NULL DEFAULT 'user', " +
                            "content TEXT NOT NULL, " +
                            "tool_logs TEXT, " +
                            "created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, " +
                            "INDEX idx_user_id (user_id), " +
                            "INDEX idx_conversation_id (conversation_id), " +
                            "INDEX idx_created_at (created_at), " +
                            "FOREIGN KEY (user_id) REFERENCES user(id) ON DELETE CASCADE, " +
                            "FOREIGN KEY (conversation_id) REFERENCES conversation(id) ON DELETE CASCADE" +
                            ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
                    
                    stmt.execute("CREATE TABLE document (" +
                            "id BIGINT AUTO_INCREMENT PRIMARY KEY, " +
                            "user_id BIGINT NOT NULL, " +
                            "file_name VARCHAR(255) NOT NULL, " +
                            "file_type VARCHAR(20) NOT NULL, " +
                            "file_size BIGINT NOT NULL, " +
                            "content LONGTEXT, " +
                            "summary TEXT, " +
                            "created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, " +
                            "updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, " +
                            "INDEX idx_user_id (user_id), " +
                            "INDEX idx_created_at (created_at), " +
                            "FOREIGN KEY (user_id) REFERENCES user(id) ON DELETE CASCADE" +
                            ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
                    
                    stmt.execute("CREATE TABLE document_vector (" +
                            "id BIGINT AUTO_INCREMENT PRIMARY KEY, " +
                            "document_id BIGINT NOT NULL, " +
                            "chunk_index INT NOT NULL, " +
                            "chunk_text TEXT NOT NULL, " +
                            "chunk_summary VARCHAR(500), " +
                            "vector_dim INT NOT NULL DEFAULT 128, " +
                            "vector_data TEXT NOT NULL, " +
                            "keywords VARCHAR(500), " +
                            "created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, " +
                            "updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, " +
                            "INDEX idx_document_id (document_id), " +
                            "INDEX idx_created_at (created_at), " +
                            "FOREIGN KEY (document_id) REFERENCES document(id) ON DELETE CASCADE" +
                            ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
                    
                    stmt.execute("CREATE TABLE agent_task_log (" +
                            "id BIGINT AUTO_INCREMENT PRIMARY KEY, " +
                            "user_id BIGINT NOT NULL, " +
                            "session_id VARCHAR(100) NOT NULL, " +
                            "tool_name VARCHAR(100) NOT NULL, " +
                            "tool_type VARCHAR(50) NOT NULL, " +
                            "input TEXT, " +
                            "output TEXT, " +
                            "status VARCHAR(20) NOT NULL DEFAULT 'pending', " +
                            "error_message TEXT, " +
                            "execution_time BIGINT, " +
                            "created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, " +
                            "INDEX idx_user_id (user_id), " +
                            "INDEX idx_session_id (session_id), " +
                            "INDEX idx_tool_name (tool_name), " +
                            "INDEX idx_created_at (created_at)" +
                            ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
                    
                    stmt.execute("CREATE TABLE link_map (" +
                            "id BIGINT AUTO_INCREMENT PRIMARY KEY, " +
                            "scene_type VARCHAR(50) NOT NULL, " +
                            "scene_name VARCHAR(100) NOT NULL, " +
                            "link_url VARCHAR(500) NOT NULL, " +
                            "link_name VARCHAR(200) NOT NULL, " +
                            "description VARCHAR(500), " +
                            "sort_order INT DEFAULT 0, " +
                            "created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, " +
                            "updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, " +
                            "INDEX idx_scene_type (scene_type)" +
                            ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
                    
                    org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder encoder = new org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder();
                    String adminPassword = encoder.encode("admin");
                    String studentPassword = encoder.encode("student");
                    stmt.execute("INSERT INTO user (username, password, nickname, avatar) VALUES " +
                            "('admin', '" + adminPassword + "', '管理员', ''), " +
                            "('student', '" + studentPassword + "', '学生用户', '')");
                    
                    stmt.execute("INSERT INTO link_map (scene_type, scene_name, link_url, link_name, description, sort_order) VALUES " +
                            "('leave', 'Leave', 'http://oa.example.com/leave', 'Leave Application', 'Submit leave application online', 1), " +
                            "('leave', 'Leave', 'http://hr.example.com/policy/leave', 'Leave Policy', 'Company leave policy and procedures', 2), " +
                            "('reimburse', 'Reimburse', 'http://oa.example.com/reimburse', 'Reimburse Application', 'Submit expense reimbursement', 1), " +
                            "('reimburse', 'Reimburse', 'http://finance.example.com/policy/reimburse', 'Reimburse Policy', 'Reimbursement standards and procedures', 2), " +
                            "('course', 'Course', 'http://edu.example.com/course', 'Course Selection', 'Online course selection system', 1), " +
                            "('course', 'Course', 'http://edu.example.com/policy/course', 'Course Guide', 'Course selection rules and schedule', 2), " +
                            "('subsidy', 'Subsidy', 'http://student.example.com/subsidy', 'Subsidy Application', 'Scholarship and grant application', 1), " +
                            "('subsidy', 'Subsidy', 'http://student.example.com/policy/subsidy', 'Subsidy Policy', 'Subsidy eligibility and procedures', 2), " +
                            "('admission', 'Admission', 'http://admission.example.com', '招生信息网', '学校招生官方网站，提供招生简章、报名入口等信息', 1), " +
                            "('admission', 'Admission', 'http://admission.example.com/apply', '在线报名系统', '新生在线报名和录取查询', 2), " +
                            "('admission', 'Admission', 'http://admission.example.com/guide', '招生指南', '招生政策、专业介绍、录取分数线等', 3)");
                    
                    log.info("Rebuilt all tables successfully");
                }
            } else {
                try (Statement stmt = conn.createStatement()) {
                    try { stmt.execute("ALTER TABLE user ADD COLUMN username VARCHAR(100) NOT NULL DEFAULT ''"); } catch (Exception ignored) {}
                    try { stmt.execute("ALTER TABLE user ADD COLUMN password VARCHAR(500) NOT NULL DEFAULT ''"); } catch (Exception ignored) {}
                    try { stmt.execute("ALTER TABLE user ADD COLUMN token_expire_time DATETIME DEFAULT NULL"); } catch (Exception ignored) {}
                    
                    try { 
                        stmt.execute("CREATE TABLE conversation (" +
                                "id BIGINT AUTO_INCREMENT PRIMARY KEY, " +
                                "user_id BIGINT NOT NULL, " +
                                "title VARCHAR(200) NOT NULL DEFAULT '新对话', " +
                                "session_id VARCHAR(100), " +
                                "created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, " +
                                "updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, " +
                                "INDEX idx_user_id (user_id), " +
                                "INDEX idx_updated_at (updated_at), " +
                                "FOREIGN KEY (user_id) REFERENCES user(id) ON DELETE CASCADE" +
                                ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
                    } catch (Exception ignored) {}
                    
                    try { 
                        stmt.execute("DROP TABLE IF EXISTS chat_history");
                        stmt.execute("CREATE TABLE chat_history (" +
                                "id BIGINT AUTO_INCREMENT PRIMARY KEY, " +
                                "user_id BIGINT NOT NULL, " +
                                "conversation_id BIGINT NOT NULL, " +
                                "role VARCHAR(20) NOT NULL DEFAULT 'user', " +
                                "content TEXT NOT NULL, " +
                                "tool_logs TEXT, " +
                                "created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, " +
                                "INDEX idx_user_id (user_id), " +
                                "INDEX idx_conversation_id (conversation_id), " +
                                "INDEX idx_created_at (created_at), " +
                                "FOREIGN KEY (user_id) REFERENCES user(id) ON DELETE CASCADE, " +
                                "FOREIGN KEY (conversation_id) REFERENCES conversation(id) ON DELETE CASCADE" +
                                ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
                    } catch (Exception ignored) {}
                    
                    org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder encoder = new org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder();
                    String adminPassword = encoder.encode("admin");
                    String studentPassword = encoder.encode("student");
                    try { stmt.execute("INSERT IGNORE INTO user (username, password, nickname, avatar) VALUES " +
                            "('admin', '" + adminPassword + "', '管理员', ''), " +
                            "('student', '" + studentPassword + "', '学生用户', '')"); } catch (Exception ignored) {}
                    log.info("Migrated database tables");
                }
            }
            
        } catch (Exception e) {
            log.error("Failed to migrate database", e);
        }
    }

    private boolean containsIgnoreCase(List<String> list, String item) {
        for (String s : list) {
            if (s.equalsIgnoreCase(item)) {
                return true;
            }
        }
        return false;
    }

    private List<String> getExistingColumns(Connection conn, String tableName) throws SQLException {
        List<String> columns = new ArrayList<>();
        DatabaseMetaData metaData = conn.getMetaData();
        try (ResultSet rs = metaData.getColumns(null, null, tableName.toUpperCase(), null)) {
            while (rs.next()) {
                columns.add(rs.getString("COLUMN_NAME"));
            }
        }
        if (columns.isEmpty()) {
            try (ResultSet rs = metaData.getColumns(null, null, tableName.toLowerCase(), null)) {
                while (rs.next()) {
                    columns.add(rs.getString("COLUMN_NAME"));
                }
            }
        }
        return columns;
    }

    private void executeSql(Connection conn, String sql) {
        try (Statement stmt = conn.createStatement()) {
            stmt.execute(sql);
        } catch (SQLException e) {
            log.warn("SQL execution warning: {}", e.getMessage());
        }
    }
}