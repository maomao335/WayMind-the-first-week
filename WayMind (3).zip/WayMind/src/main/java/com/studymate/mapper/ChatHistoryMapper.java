package com.studymate.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.studymate.entity.ChatHistory;
import org.apache.ibatis.annotations.Select;

import java.util.List;

public interface ChatHistoryMapper extends BaseMapper<ChatHistory> {

    @Select("SELECT * FROM chat_history WHERE conversation_id = #{conversationId} AND user_id = #{userId} ORDER BY created_at ASC")
    List<ChatHistory> selectByConversationId(Long conversationId, Long userId);

    @Select("SELECT * FROM chat_history WHERE conversation_id = #{conversationId} AND user_id = #{userId} ORDER BY created_at DESC LIMIT #{limit}")
    List<ChatHistory> selectRecentByConversationId(Long conversationId, Long userId, int limit);

    @Select("SELECT COUNT(*) FROM chat_history WHERE conversation_id = #{conversationId} AND user_id = #{userId}")
    int countByConversationId(Long conversationId, Long userId);
}