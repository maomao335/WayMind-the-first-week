package com.studymate.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.studymate.entity.Conversation;
import org.apache.ibatis.annotations.Select;

import java.util.List;

public interface ConversationMapper extends BaseMapper<Conversation> {

    @Select("SELECT * FROM conversation WHERE user_id = #{userId} ORDER BY updated_at DESC")
    List<Conversation> selectByUserId(Long userId);

    @Select("SELECT * FROM conversation WHERE id = #{id} AND user_id = #{userId}")
    Conversation selectByIdAndUserId(Long id, Long userId);
}