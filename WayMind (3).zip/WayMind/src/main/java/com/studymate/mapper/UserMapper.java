package com.studymate.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.studymate.entity.User;
import org.apache.ibatis.annotations.Select;

public interface UserMapper extends BaseMapper<User> {

    @Select("SELECT * FROM user WHERE username = #{username} LIMIT 1")
    User selectByUsername(String username);
}
