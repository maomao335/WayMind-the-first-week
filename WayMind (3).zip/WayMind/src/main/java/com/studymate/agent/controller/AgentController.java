package com.studymate.agent.controller;

import com.studymate.agent.entity.AgentTaskLog;
import com.studymate.agent.mapper.AgentTaskLogMapper;
import com.studymate.agent.registry.ToolRegistry;
import com.studymate.agent.registry.ToolRegistry.ToolType;
import com.studymate.agent.service.AgentCoreService;
import com.studymate.dto.ApiResponse;
import com.studymate.dto.ChatResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/agent")
@CrossOrigin(origins = "*")
public class AgentController {

    @Autowired
    private AgentCoreService agentCoreService;

    @Autowired
    private AgentTaskLogMapper taskLogMapper;

    @Autowired
    private ToolRegistry toolRegistry;

    @PostMapping("/chat")
    public ApiResponse<ChatResponse> chat(
            @RequestParam(value = "userId", required = false) Long userId,
            @RequestParam("message") String message,
            @RequestParam(value = "sessionId", required = false) String sessionId) {
        
        if (sessionId == null || sessionId.isEmpty()) {
            sessionId = UUID.randomUUID().toString();
        }

        ChatResponse response = agentCoreService.execute(userId, sessionId, message);
        response.setSessionId(sessionId);
        return ApiResponse.success(response);
    }

    @GetMapping("/tools")
    public ApiResponse<List<Map<String, Object>>> listTools() {
        List<ToolType> tools = toolRegistry.getAllTools();
        List<Map<String, Object>> result = tools.stream().map(tool -> {
            Map<String, Object> map = new HashMap<>();
            map.put("name", tool.getName());
            map.put("description", tool.getDescription());
            map.put("category", tool.getCategory());
            return map;
        }).toList();
        return ApiResponse.success(result);
    }

    @GetMapping("/logs")
    public ApiResponse<List<AgentTaskLog>> getLogs(
            @RequestParam(value = "sessionId", required = false) String sessionId,
            @RequestParam(value = "userId", required = false) Long userId,
            @RequestParam(value = "toolName", required = false) String toolName,
            @RequestParam(value = "limit", defaultValue = "20") int limit) {
        
        List<AgentTaskLog> logs;
        
        if (sessionId != null && !sessionId.isEmpty()) {
            logs = taskLogMapper.selectBySessionId(sessionId);
        } else if (userId != null) {
            logs = taskLogMapper.selectByUserId(userId, limit);
        } else if (toolName != null && !toolName.isEmpty()) {
            logs = taskLogMapper.selectByToolName(toolName, limit);
        } else {
            logs = taskLogMapper.selectRecent(limit);
        }
        
        return ApiResponse.success(logs);
    }

    @GetMapping("/stats")
    public ApiResponse<Map<String, Object>> getStats() {
        List<AgentTaskLog> allLogs = taskLogMapper.selectRecent(1000);
        
        Map<String, Object> stats = new HashMap<>();
        stats.put("totalTasks", allLogs.size());
        
        Map<String, Integer> toolCount = new HashMap<>();
        Map<String, Integer> statusCount = new HashMap<>();
        
        for (AgentTaskLog log : allLogs) {
            toolCount.put(log.getToolName(), toolCount.getOrDefault(log.getToolName(), 0) + 1);
            statusCount.put(log.getStatus(), statusCount.getOrDefault(log.getStatus(), 0) + 1);
        }
        
        stats.put("toolCount", toolCount);
        stats.put("statusCount", statusCount);
        
        return ApiResponse.success(stats);
    }

    @GetMapping("/session/{sessionId}")
    public ApiResponse<Map<String, Object>> getSessionInfo(@PathVariable String sessionId) {
        List<AgentTaskLog> logs = taskLogMapper.selectBySessionId(sessionId);
        
        Map<String, Object> info = new HashMap<>();
        info.put("sessionId", sessionId);
        info.put("taskCount", logs.size());
        info.put("tasks", logs);
        
        return ApiResponse.success(info);
    }
}