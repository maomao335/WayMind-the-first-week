package com.studymate.agent.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.studymate.agent.entity.AgentTaskLog;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface AgentTaskLogMapper extends BaseMapper<AgentTaskLog> {

    @Select("SELECT * FROM agent_task_log WHERE session_id = #{sessionId} ORDER BY created_at DESC")
    List<AgentTaskLog> selectBySessionId(String sessionId);

    @Select("SELECT * FROM agent_task_log WHERE user_id = #{userId} ORDER BY created_at DESC LIMIT #{limit}")
    List<AgentTaskLog> selectByUserId(Long userId, int limit);

    @Select("SELECT * FROM agent_task_log WHERE tool_name = #{toolName} ORDER BY created_at DESC LIMIT #{limit}")
    List<AgentTaskLog> selectByToolName(String toolName, int limit);

    @Select("SELECT COUNT(*) FROM agent_task_log WHERE session_id = #{sessionId}")
    int countBySessionId(String sessionId);

    @Select("SELECT * FROM agent_task_log ORDER BY created_at DESC LIMIT #{limit}")
    List<AgentTaskLog> selectRecent(int limit);
}