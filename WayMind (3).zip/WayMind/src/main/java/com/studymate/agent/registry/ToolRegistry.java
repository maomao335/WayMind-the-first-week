package com.studymate.agent.registry;

import com.studymate.dto.SkillResponse;
import com.studymate.mcp.McpCampusService;
import com.studymate.mcp.McpCampusService.McpServiceType;
import com.studymate.rag.entity.DocumentVector;
import com.studymate.rag.service.VectorSearchService;
import com.studymate.service.DialogClarifyService;
import com.studymate.service.LinkGenerateService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

@Component
public class ToolRegistry {

    public enum ToolType {
        RAG_SEARCH("rag_search", "RAG检索", "retrieval"),
        FILE_PARSE("file_parse", "文件解析", "skill"),
        DIALOG_CLARIFY("dialog_clarify", "多轮澄清", "skill"),
        LINK_GENERATE("link_generate", "办事链接", "skill"),
        AI_CHAT("ai_chat", "AI对话", "model"),
        MCP_HOLIDAY("mcp_holiday", "放假通知", "mcp"),
        MCP_REIMBURSE("mcp_reimburse", "报销进度", "mcp"),
        MCP_COURSE("mcp_course", "选课余量", "mcp"),
        MCP_CAMPUS_CARD("mcp_campus_card", "校园卡通知", "mcp");

        private final String name;
        private final String description;
        private final String category;

        ToolType(String name, String description, String category) {
            this.name = name;
            this.description = description;
            this.category = category;
        }

        public String getName() {
            return name;
        }

        public String getDescription() {
            return description;
        }

        public String getCategory() {
            return category;
        }
    }

    @Autowired
    private VectorSearchService vectorSearchService;

    @Autowired
    private DialogClarifyService dialogClarifyService;

    @Autowired
    private LinkGenerateService linkGenerateService;

    @Autowired
    private McpCampusService mcpCampusService;

    private final Map<ToolType, Function<ToolInput, ToolOutput>> toolMap = new HashMap<>();

    public ToolRegistry() {
        initializeTools();
    }

    private void initializeTools() {
        toolMap.put(ToolType.RAG_SEARCH, this::executeRagSearch);
        toolMap.put(ToolType.DIALOG_CLARIFY, this::executeDialogClarify);
        toolMap.put(ToolType.LINK_GENERATE, this::executeLinkGenerate);
        toolMap.put(ToolType.MCP_HOLIDAY, this::executeMcpHoliday);
        toolMap.put(ToolType.MCP_REIMBURSE, this::executeMcpReimburse);
        toolMap.put(ToolType.MCP_COURSE, this::executeMcpCourse);
        toolMap.put(ToolType.MCP_CAMPUS_CARD, this::executeMcpCampusCard);
    }

    public ToolOutput executeTool(ToolType toolType, ToolInput input) {
        Function<ToolInput, ToolOutput> handler = toolMap.get(toolType);
        if (handler == null) {
            return ToolOutput.error("Tool not found: " + toolType.name());
        }
        return handler.apply(input);
    }

    private ToolOutput executeRagSearch(ToolInput input) {
        try {
            String query = input.getParams().get("query");
            Integer topN = Integer.parseInt(input.getParams().getOrDefault("topN", "3"));
            Long userId = input.getUserId();

            List<DocumentVector> results = vectorSearchService.searchSimilar(query, topN, userId);
            String context = vectorSearchService.buildContextFromResults(results);

            Map<String, Object> result = new HashMap<>();
            result.put("chunks", results);
            result.put("context", context);
            result.put("matchCount", results.size());

            return ToolOutput.success(result);
        } catch (Exception e) {
            return ToolOutput.error("RAG search failed: " + e.getMessage());
        }
    }

    private ToolOutput executeDialogClarify(ToolInput input) {
        try {
            String message = input.getParams().get("message");
            Long userId = input.getUserId();

            SkillResponse response = dialogClarifyService.clarify(userId, message);

            Map<String, Object> result = new HashMap<>();
            result.put("result", response.getResult());
            result.put("sceneType", response.getSceneType());
            result.put("sceneName", response.getSceneName());

            return ToolOutput.success(result);
        } catch (Exception e) {
            return ToolOutput.error("Dialog clarify failed: " + e.getMessage());
        }
    }

    private ToolOutput executeLinkGenerate(ToolInput input) {
        try {
            String message = input.getParams().get("message");
            Long userId = input.getUserId();

            SkillResponse response = linkGenerateService.generateLinks(userId, message);

            Map<String, Object> result = new HashMap<>();
            result.put("result", response.getResult());
            result.put("sceneType", response.getSceneType());
            result.put("sceneName", response.getSceneName());

            List<Map<String, Object>> linkMaps = new ArrayList<>();
            if (response.getLinks() != null) {
                for (SkillResponse.LinkInfo link : response.getLinks()) {
                    Map<String, Object> linkMap = new HashMap<>();
                    linkMap.put("name", link.getName());
                    linkMap.put("url", link.getUrl());
                    linkMap.put("description", link.getDescription());
                    linkMaps.add(linkMap);
                }
            }
            result.put("links", linkMaps);

            return ToolOutput.success(result);
        } catch (Exception e) {
            return ToolOutput.error("Link generate failed: " + e.getMessage());
        }
    }

    private ToolOutput executeMcpHoliday(ToolInput input) {
        try {
            String query = input.getParams().get("query");
            Map<String, Object> result = mcpCampusService.getHolidayNotice(query);
            return ToolOutput.success(result);
        } catch (Exception e) {
            return ToolOutput.error("MCP holiday query failed: " + e.getMessage());
        }
    }

    private ToolOutput executeMcpReimburse(ToolInput input) {
        try {
            String query = input.getParams().get("query");
            Map<String, Object> result = mcpCampusService.getReimburseProgress(query);
            return ToolOutput.success(result);
        } catch (Exception e) {
            return ToolOutput.error("MCP reimburse query failed: " + e.getMessage());
        }
    }

    private ToolOutput executeMcpCourse(ToolInput input) {
        try {
            String query = input.getParams().get("query");
            Map<String, Object> result = mcpCampusService.getCourseQuota(query);
            return ToolOutput.success(result);
        } catch (Exception e) {
            return ToolOutput.error("MCP course query failed: " + e.getMessage());
        }
    }

    private ToolOutput executeMcpCampusCard(ToolInput input) {
        try {
            String query = input.getParams().get("query");
            Map<String, Object> result = mcpCampusService.getCampusCardInfo(query);
            return ToolOutput.success(result);
        } catch (Exception e) {
            return ToolOutput.error("MCP campus card query failed: " + e.getMessage());
        }
    }

    public boolean hasTool(ToolType toolType) {
        return toolMap.containsKey(toolType);
    }

    public List<ToolType> getAllTools() {
        return new ArrayList<>(toolMap.keySet());
    }

    public static class ToolInput {
        private Long userId;
        private String sessionId;
        private Map<String, String> params;

        public Long getUserId() {
            return userId;
        }

        public void setUserId(Long userId) {
            this.userId = userId;
        }

        public String getSessionId() {
            return sessionId;
        }

        public void setSessionId(String sessionId) {
            this.sessionId = sessionId;
        }

        public Map<String, String> getParams() {
            return params;
        }

        public void setParams(Map<String, String> params) {
            this.params = params;
        }
    }

    public static class ToolOutput {
        private boolean success;
        private String error;
        private Map<String, Object> data;

        public boolean isSuccess() {
            return success;
        }

        public void setSuccess(boolean success) {
            this.success = success;
        }

        public String getError() {
            return error;
        }

        public void setError(String error) {
            this.error = error;
        }

        public Map<String, Object> getData() {
            return data;
        }

        public void setData(Map<String, Object> data) {
            this.data = data;
        }

        public static ToolOutput success(Map<String, Object> data) {
            ToolOutput output = new ToolOutput();
            output.setSuccess(true);
            output.setData(data);
            return output;
        }

        public static ToolOutput error(String error) {
            ToolOutput output = new ToolOutput();
            output.setSuccess(false);
            output.setError(error);
            return output;
        }
    }
}