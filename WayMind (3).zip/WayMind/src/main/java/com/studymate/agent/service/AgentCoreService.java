package com.studymate.agent.service;

import com.studymate.dto.ChatResponse;

public interface AgentCoreService {

    ChatResponse execute(Long userId, String sessionId, String message);

    ChatResponse execute(Long userId, String sessionId, String message, String context);
}