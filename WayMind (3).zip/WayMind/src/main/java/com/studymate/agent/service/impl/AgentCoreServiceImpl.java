package com.studymate.agent.service.impl;

import com.studymate.agent.entity.AgentTaskLog;
import com.studymate.agent.mapper.AgentTaskLogMapper;
import com.studymate.agent.registry.ToolRegistry;
import com.studymate.agent.registry.ToolRegistry.ToolInput;
import com.studymate.agent.registry.ToolRegistry.ToolOutput;
import com.studymate.agent.registry.ToolRegistry.ToolType;
import com.studymate.dto.ChatResponse;
import com.studymate.util.IntentRecognizerUtil;
import com.studymate.util.QianWenClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.*;
import java.util.regex.Pattern;

@Service
public class AgentCoreServiceImpl implements com.studymate.agent.service.AgentCoreService {

    @Autowired
    private ToolRegistry toolRegistry;

    @Autowired
    private QianWenClient qianWenClient;

    @Autowired
    private AgentTaskLogMapper taskLogMapper;

    @Autowired
    private IntentRecognizerUtil intentRecognizerUtil;

    private static final Pattern ADMISSION_PATTERN = Pattern.compile("招生|录取|报考|入学|招生简章|录取分数线|志愿填报", Pattern.CASE_INSENSITIVE);
    private static final Pattern DOC_QA_PATTERN = Pattern.compile("文档|文件|内容|摘要|根据.*文档|基于.*文件", Pattern.CASE_INSENSITIVE);
    private static final Pattern CHAT_PATTERN = Pattern.compile("你好|嗨|在吗|聊聊天|随便说说|最近怎么样|推荐美食|推荐好吃的|好吃的|美食|推荐电视剧|推荐电影|推荐书籍|推荐音乐|有什么好看的|有什么好玩的|聊聊|聊天", Pattern.CASE_INSENSITIVE);
    private static final Pattern HOLIDAY_PATTERN = Pattern.compile("放假|假期|国庆|中秋|元旦|放假安排", Pattern.CASE_INSENSITIVE);
    private static final Pattern CAMPUS_CARD_PATTERN = Pattern.compile("校园卡|饭卡|充值|余额|消费", Pattern.CASE_INSENSITIVE);

    public enum IntentType {
        ADMISSION("招生咨询"),
        REIMBURSE("报销"),
        COURSE("选课"),
        LEAVE("请假"),
        SUBSIDY("补助"),
        DOC_QA("文档问答"),
        CHAT("闲聊"),
        HOLIDAY("放假查询"),
        CAMPUS_CARD("校园卡"),
        OTHER("其他");

        private final String description;

        IntentType(String description) {
            this.description = description;
        }

        public String getDescription() {
            return description;
        }
    }

    @Override
    public ChatResponse execute(Long userId, String sessionId, String message) {
        return execute(userId, sessionId, message, null);
    }

    @Override
    public ChatResponse execute(Long userId, String sessionId, String message, String conversationContext) {
        if (message == null || message.trim().isEmpty()) {
            return createResponse("请输入您的问题", userId);
        }

        if (sessionId == null || sessionId.isEmpty()) {
            sessionId = UUID.randomUUID().toString();
        }

        IntentType intent = recognizeIntent(message);
        List<ToolType> toolsToCall = determineTools(intent);

        Map<String, Object> toolResults = new HashMap<>();
        List<com.studymate.dto.ChatResponse.ToolCallLog> toolLogs = new ArrayList<>();
        String context = conversationContext != null ? conversationContext : "";
        String clarifyReply = null;

        for (ToolType tool : toolsToCall) {
            ToolOutput output = callTool(tool, userId, sessionId, message);
            logToolCall(userId, sessionId, tool, message, output);

            com.studymate.dto.ChatResponse.ToolCallLog log = new com.studymate.dto.ChatResponse.ToolCallLog();
            log.setToolName(tool.getDescription());
            log.setToolType(tool.getCategory());
            log.setSuccess(output.isSuccess());
            log.setError(output.isSuccess() ? null : output.getError());
            
            if (output.isSuccess()) {
                toolResults.put(tool.getName(), output.getData());
                String summary = buildToolOutputSummary(tool, output.getData());
                log.setOutputSummary(summary);

                if (tool == ToolType.RAG_SEARCH) {
                    String ragContext = (String) output.getData().get("context");
                    if (ragContext != null && !ragContext.isEmpty()) {
                        context += ragContext + "\n\n";
                    }
                }

                if (tool == ToolType.DIALOG_CLARIFY) {
                    clarifyReply = (String) output.getData().get("result");
                }
            }
            toolLogs.add(log);
        }

        if (clarifyReply != null && !clarifyReply.isEmpty()) {
            return createResponse(clarifyReply, userId, toolLogs);
        }

        String finalMessage = buildFinalMessage(message, context, toolResults);

        String aiReply;
        try {
            aiReply = qianWenClient.chat(finalMessage);
        } catch (Exception e) {
            aiReply = "抱歉，AI服务暂时不可用，请稍后再试。";
        }

        return createResponse(aiReply, userId, toolLogs);
    }

    private String buildToolOutputSummary(ToolType tool, Map<String, Object> data) {
        return switch (tool) {
            case RAG_SEARCH -> "匹配到 " + data.get("matchCount") + " 条文档片段";
            case LINK_GENERATE -> {
                List<?> links = (List<?>) data.get("links");
                yield "生成 " + (links != null ? links.size() : 0) + " 个办事链接";
            }
            case DIALOG_CLARIFY -> "场景识别：" + data.get("sceneName");
            case MCP_HOLIDAY -> "获取到 " + data.get("count") + " 条放假通知";
            case MCP_REIMBURSE -> "查询到 " + data.get("count") + " 条报销记录";
            case MCP_COURSE -> "查询到 " + data.get("count") + " 门课程余量";
            case MCP_CAMPUS_CARD -> "获取校园卡信息及通知";
            default -> "工具执行成功";
        };
    }

    private IntentType recognizeIntent(String message) {
        if (ADMISSION_PATTERN.matcher(message).find()) {
            return IntentType.ADMISSION;
        }

        if (HOLIDAY_PATTERN.matcher(message).find()) {
            return IntentType.HOLIDAY;
        }

        if (CAMPUS_CARD_PATTERN.matcher(message).find()) {
            return IntentType.CAMPUS_CARD;
        }

        if (DOC_QA_PATTERN.matcher(message).find()) {
            return IntentType.DOC_QA;
        }

        if (CHAT_PATTERN.matcher(message).find()) {
            return IntentType.CHAT;
        }

        IntentRecognizerUtil.SceneType sceneType = intentRecognizerUtil.recognize(message);
        switch (sceneType) {
            case LEAVE:
                return IntentType.LEAVE;
            case REIMBURSE:
                return IntentType.REIMBURSE;
            case COURSE:
                return IntentType.COURSE;
            case SUBSIDY:
                return IntentType.SUBSIDY;
            default:
                return IntentType.OTHER;
        }
    }

    private List<ToolType> determineTools(IntentType intent) {
        List<ToolType> tools = new ArrayList<>();

        switch (intent) {
            case ADMISSION:
                tools.add(ToolType.DIALOG_CLARIFY);
                tools.add(ToolType.RAG_SEARCH);
                tools.add(ToolType.LINK_GENERATE);
                break;
            case REIMBURSE:
                tools.add(ToolType.DIALOG_CLARIFY);
                tools.add(ToolType.RAG_SEARCH);
                tools.add(ToolType.LINK_GENERATE);
                tools.add(ToolType.MCP_REIMBURSE);
                break;
            case COURSE:
                tools.add(ToolType.DIALOG_CLARIFY);
                tools.add(ToolType.RAG_SEARCH);
                tools.add(ToolType.LINK_GENERATE);
                tools.add(ToolType.MCP_COURSE);
                break;
            case LEAVE:
                tools.add(ToolType.DIALOG_CLARIFY);
                tools.add(ToolType.RAG_SEARCH);
                tools.add(ToolType.LINK_GENERATE);
                tools.add(ToolType.MCP_HOLIDAY);
                break;
            case SUBSIDY:
                tools.add(ToolType.DIALOG_CLARIFY);
                tools.add(ToolType.RAG_SEARCH);
                tools.add(ToolType.LINK_GENERATE);
                break;
            case DOC_QA:
                tools.add(ToolType.RAG_SEARCH);
                break;
            case HOLIDAY:
                tools.add(ToolType.DIALOG_CLARIFY);
                tools.add(ToolType.MCP_HOLIDAY);
                tools.add(ToolType.RAG_SEARCH);
                break;
            case CAMPUS_CARD:
                tools.add(ToolType.DIALOG_CLARIFY);
                tools.add(ToolType.MCP_CAMPUS_CARD);
                tools.add(ToolType.RAG_SEARCH);
                break;
            case OTHER:
                tools.add(ToolType.DIALOG_CLARIFY);
                tools.add(ToolType.RAG_SEARCH);
                tools.add(ToolType.LINK_GENERATE);
                break;
            case CHAT:
                break;
        }

        return tools;
    }

    private ToolOutput callTool(ToolType toolType, Long userId, String sessionId, String message) {
        ToolInput input = new ToolInput();
        input.setUserId(userId);
        input.setSessionId(sessionId);

        Map<String, String> params = new HashMap<>();
        params.put("message", message);
        params.put("query", message);
        params.put("topN", "3");

        input.setParams(params);

        return toolRegistry.executeTool(toolType, input);
    }

    private void logToolCall(Long userId, String sessionId, ToolType toolType, String input, ToolOutput output) {
        AgentTaskLog log = new AgentTaskLog();
        log.setUserId(userId != null ? userId : 0L);
        log.setSessionId(sessionId);
        log.setToolName(toolType.getName());
        log.setToolType(toolType.getCategory());
        log.setInput(input);
        log.setOutput(output.isSuccess() ? output.getData().toString() : output.getError());
        log.setStatus(output.isSuccess() ? "success" : "failed");
        log.setErrorMessage(output.isSuccess() ? null : output.getError());
        log.setCreatedAt(LocalDateTime.now());

        taskLogMapper.insert(log);
    }

    private String buildFinalMessage(String originalMessage, String context, Map<String, Object> toolResults) {
        StringBuilder message = new StringBuilder();

        if (!context.isEmpty()) {
            message.append("【参考信息】\n");
            message.append(context);
            message.append("\n\n");
        }

        if (toolResults.containsKey(ToolType.MCP_HOLIDAY.getName())) {
            Map<String, Object> holidayResult = (Map<String, Object>) toolResults.get(ToolType.MCP_HOLIDAY.getName());
            List<Map<String, Object>> notices = (List<Map<String, Object>>) holidayResult.get("notices");
            if (notices != null && !notices.isEmpty()) {
                message.append("【放假通知】\n");
                for (Map<String, Object> notice : notices) {
                    message.append("- ").append(notice.get("title")).append("：").append(notice.get("date")).append("，假期").append(notice.get("duration")).append("\n");
                    message.append("  ").append(notice.get("content")).append("\n");
                }
                message.append("\n");
            }
        }

        if (toolResults.containsKey(ToolType.MCP_REIMBURSE.getName())) {
            Map<String, Object> reimburseResult = (Map<String, Object>) toolResults.get(ToolType.MCP_REIMBURSE.getName());
            List<Map<String, Object>> records = (List<Map<String, Object>>) reimburseResult.get("records");
            if (records != null && !records.isEmpty()) {
                message.append("【报销进度】\n");
                for (Map<String, Object> record : records) {
                    message.append("- 单号").append(record.get("id")).append("：").append(record.get("type")).append("，金额").append(record.get("amount")).append("元，状态：").append(record.get("status")).append("\n");
                    message.append("  ").append(record.get("statusDesc")).append("\n");
                }
                message.append("\n");
            }
        }

        if (toolResults.containsKey(ToolType.MCP_COURSE.getName())) {
            Map<String, Object> courseResult = (Map<String, Object>) toolResults.get(ToolType.MCP_COURSE.getName());
            List<Map<String, Object>> courses = (List<Map<String, Object>>) courseResult.get("courses");
            if (courses != null && !courses.isEmpty()) {
                message.append("【选课余量】\n");
                for (Map<String, Object> course : courses) {
                    message.append("- ").append(course.get("name")).append("（").append(course.get("id")).append("）：").append(course.get("teacher")).append("\n");
                    message.append("  时间：").append(course.get("time")).append("，地点：").append(course.get("location")).append("\n");
                    message.append("  剩余名额：").append(course.get("remainingQuota")).append("/").append(course.get("totalQuota")).append("（").append(course.get("status")).append("）\n");
                }
                message.append("\n");
            }
        }

        if (toolResults.containsKey(ToolType.MCP_CAMPUS_CARD.getName())) {
            Map<String, Object> cardResult = (Map<String, Object>) toolResults.get(ToolType.MCP_CAMPUS_CARD.getName());
            Map<String, Object> cardInfo = (Map<String, Object>) cardResult.get("cardInfo");
            List<Map<String, Object>> notifications = (List<Map<String, Object>>) cardResult.get("notifications");
            
            if (cardInfo != null) {
                message.append("【校园卡信息】\n");
                message.append("卡号：").append(cardInfo.get("cardNo")).append("\n");
                message.append("余额：").append(cardInfo.get("balance")).append("元，状态：").append(cardInfo.get("status")).append("\n");
                message.append("\n");
            }
            
            if (notifications != null && !notifications.isEmpty()) {
                message.append("【校园卡通知】\n");
                for (Map<String, Object> notify : notifications) {
                    message.append("- ").append(notify.get("title")).append("：").append(notify.get("content")).append("\n");
                }
                message.append("\n");
            }
        }

        if (toolResults.containsKey(ToolType.LINK_GENERATE.getName())) {
            Map<String, Object> linkResult = (Map<String, Object>) toolResults.get(ToolType.LINK_GENERATE.getName());
            List<Map<String, Object>> links = (List<Map<String, Object>>) linkResult.get("links");
            if (links != null && !links.isEmpty()) {
                message.append("【相关链接】\n");
                for (Map<String, Object> link : links) {
                    message.append("- ").append(link.get("name")).append(": ").append(link.get("url")).append("\n");
                }
                message.append("\n");
            }
        }

        if (toolResults.containsKey(ToolType.DIALOG_CLARIFY.getName())) {
            Map<String, Object> clarifyResult = (Map<String, Object>) toolResults.get(ToolType.DIALOG_CLARIFY.getName());
            String sceneName = (String) clarifyResult.get("sceneName");
            if (sceneName != null) {
                message.append("【场景识别】").append(sceneName).append("\n\n");
            }
        }

        message.append("【用户问题】").append(originalMessage);

        return message.toString();
    }

    private ChatResponse createResponse(String reply, Long userId) {
        ChatResponse response = new ChatResponse();
        response.setReply(reply);
        response.setUserId(userId);
        response.setToolLogs(new ArrayList<>());
        return response;
    }

    private ChatResponse createResponse(String reply, Long userId, List<com.studymate.dto.ChatResponse.ToolCallLog> toolLogs) {
        ChatResponse response = new ChatResponse();
        response.setReply(reply);
        response.setUserId(userId);
        response.setToolLogs(toolLogs);
        return response;
    }
}