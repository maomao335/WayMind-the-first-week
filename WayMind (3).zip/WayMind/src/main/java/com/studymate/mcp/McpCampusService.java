package com.studymate.mcp;

import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

@Service
public class McpCampusService {

    public enum McpServiceType {
        HOLIDAY_NOTICE("放假通知查询"),
        REIMBURSE_PROGRESS("报销进度查询"),
        COURSE_QUOTA("选课余量查询"),
        CAMPUS_CARD("校园卡通知");

        private final String description;

        McpServiceType(String description) {
            this.description = description;
        }

        public String getDescription() {
            return description;
        }
    }

    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    public Map<String, Object> getHolidayNotice(String query) {
        Map<String, Object> result = new HashMap<>();
        result.put("service", "holiday_notice");
        result.put("serviceName", "放假通知查询");
        
        List<Map<String, Object>> notices = new ArrayList<>();
        
        Map<String, Object> notice1 = new HashMap<>();
        notice1.put("title", "2024年国庆节放假安排");
        notice1.put("date", "2024-10-01");
        notice1.put("duration", "7天");
        notice1.put("content", "根据国务院办公厅通知，2024年国庆节放假调休安排如下：10月1日至7日放假调休，共7天。9月29日（星期日）、10月12日（星期六）上班。");
        notice1.put("source", "学校办公室");
        notices.add(notice1);

        Map<String, Object> notice2 = new HashMap<>();
        notice2.put("title", "中秋节放假通知");
        notice2.put("date", "2024-09-17");
        notice2.put("duration", "1天");
        notice2.put("content", "中秋节当天放假1天，请各单位做好假期值班安排。");
        notice2.put("source", "学校办公室");
        notices.add(notice2);

        Map<String, Object> notice3 = new HashMap<>();
        notice3.put("title", "元旦放假安排");
        notice3.put("date", "2025-01-01");
        notice3.put("duration", "1天");
        notice3.put("content", "2025年元旦放假1天，不调休。");
        notice3.put("source", "学校办公室");
        notices.add(notice3);

        result.put("notices", notices);
        result.put("count", notices.size());
        result.put("queryTime", LocalDateTime.now().format(FORMATTER));
        
        return result;
    }

    public Map<String, Object> getReimburseProgress(String query) {
        Map<String, Object> result = new HashMap<>();
        result.put("service", "reimburse_progress");
        result.put("serviceName", "报销进度查询");

        List<Map<String, Object>> records = new ArrayList<>();

        Map<String, Object> record1 = new HashMap<>();
        record1.put("id", "RB-2024-001");
        record1.put("type", "差旅费");
        record1.put("amount", "2,500.00");
        record1.put("status", "审核通过");
        record1.put("statusDesc", "财务已打款，预计3个工作日到账");
        record1.put("applyTime", "2024-09-15 10:30:00");
        record1.put("lastUpdate", "2024-09-18 14:20:00");
        records.add(record1);

        Map<String, Object> record2 = new HashMap<>();
        record2.put("id", "RB-2024-002");
        record2.put("type", "办公用品");
        record2.put("amount", "580.00");
        record2.put("status", "部门审核");
        record2.put("statusDesc", "等待部门负责人审批");
        record2.put("applyTime", "2024-09-20 09:15:00");
        record2.put("lastUpdate", "2024-09-20 09:15:00");
        records.add(record2);

        Map<String, Object> record3 = new HashMap<>();
        record3.put("id", "RB-2024-003");
        record3.put("type", "培训费");
        record3.put("amount", "3,200.00");
        record3.put("status", "已退回");
        record3.put("statusDesc", "发票信息不全，请补充后重新提交");
        record3.put("applyTime", "2024-09-10 16:45:00");
        record3.put("lastUpdate", "2024-09-12 11:00:00");
        records.add(record3);

        result.put("records", records);
        result.put("count", records.size());
        result.put("queryTime", LocalDateTime.now().format(FORMATTER));

        return result;
    }

    public Map<String, Object> getCourseQuota(String query) {
        Map<String, Object> result = new HashMap<>();
        result.put("service", "course_quota");
        result.put("serviceName", "选课余量查询");

        List<Map<String, Object>> courses = new ArrayList<>();

        Map<String, Object> course1 = new HashMap<>();
        course1.put("id", "CS101");
        course1.put("name", "人工智能导论");
        course1.put("teacher", "张教授");
        course1.put("totalQuota", 120);
        course1.put("currentCount", 85);
        course1.put("remainingQuota", 35);
        course1.put("time", "周一 1-2节");
        course1.put("location", "教学楼A-301");
        course1.put("status", "可选");
        courses.add(course1);

        Map<String, Object> course2 = new HashMap<>();
        course2.put("id", "CS102");
        course2.put("name", "数据结构与算法");
        course2.put("teacher", "李教授");
        course2.put("totalQuota", 100);
        course2.put("currentCount", 100);
        course2.put("remainingQuota", 0);
        course2.put("time", "周二 3-4节");
        course2.put("location", "教学楼B-205");
        course2.put("status", "已满");
        courses.add(course2);

        Map<String, Object> course3 = new HashMap<>();
        course3.put("id", "CS103");
        course3.put("name", "计算机网络");
        course3.put("teacher", "王教授");
        course3.put("totalQuota", 80);
        course3.put("currentCount", 78);
        course3.put("remainingQuota", 2);
        course3.put("time", "周三 5-6节");
        course3.put("location", "实验楼C-102");
        course3.put("status", "即将满");
        courses.add(course3);

        Map<String, Object> course4 = new HashMap<>();
        course4.put("id", "CS104");
        course4.put("name", "数据库系统");
        course4.put("teacher", "赵教授");
        course4.put("totalQuota", 90);
        course4.put("currentCount", 45);
        course4.put("remainingQuota", 45);
        course4.put("time", "周四 1-2节");
        course4.put("location", "教学楼A-401");
        course4.put("status", "可选");
        courses.add(course4);

        result.put("courses", courses);
        result.put("count", courses.size());
        result.put("queryTime", LocalDateTime.now().format(FORMATTER));

        return result;
    }

    public Map<String, Object> getCampusCardInfo(String query) {
        Map<String, Object> result = new HashMap<>();
        result.put("service", "campus_card");
        result.put("serviceName", "校园卡通知");

        List<Map<String, Object>> notifications = new ArrayList<>();

        Map<String, Object> notify1 = new HashMap<>();
        notify1.put("type", "余额提醒");
        notify1.put("title", "校园卡余额不足");
        notify1.put("content", "您的校园卡余额为15.50元，请及时充值。");
        notify1.put("time", "2024-09-20 08:30:00");
        notify1.put("level", "warning");
        notifications.add(notify1);

        Map<String, Object> notify2 = new HashMap<>();
        notify2.put("type", "消费记录");
        notify2.put("title", "食堂消费");
        notify2.put("content", "您于2024-09-20 12:15:00在第二食堂消费15.00元");
        notify2.put("time", "2024-09-20 12:15:00");
        notify2.put("level", "info");
        notifications.add(notify2);

        Map<String, Object> notify3 = new HashMap<>();
        notify3.put("type", "充值成功");
        notify3.put("title", "校园卡充值成功");
        notify3.put("content", "您的校园卡已充值200.00元，当前余额215.50元");
        notify3.put("time", "2024-09-19 20:00:00");
        notify3.put("level", "success");
        notifications.add(notify3);

        Map<String, Object> cardInfo = new HashMap<>();
        cardInfo.put("cardNo", "622202******1234");
        cardInfo.put("balance", 15.50);
        cardInfo.put("status", "正常");
        cardInfo.put("lastRecharge", "2024-09-19 20:00:00");
        cardInfo.put("lastConsume", "2024-09-20 12:15:00");

        result.put("notifications", notifications);
        result.put("cardInfo", cardInfo);
        result.put("queryTime", LocalDateTime.now().format(FORMATTER));

        return result;
    }

    public Map<String, Object> execute(McpServiceType serviceType, String query) {
        return switch (serviceType) {
            case HOLIDAY_NOTICE -> getHolidayNotice(query);
            case REIMBURSE_PROGRESS -> getReimburseProgress(query);
            case COURSE_QUOTA -> getCourseQuota(query);
            case CAMPUS_CARD -> getCampusCardInfo(query);
        };
    }
}