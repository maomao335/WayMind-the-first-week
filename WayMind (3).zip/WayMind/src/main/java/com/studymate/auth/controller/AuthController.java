package com.studymate.auth.controller;

import com.studymate.dto.ApiResponse;
import com.studymate.entity.User;
import com.studymate.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired
    private UserService userService;

    @PostMapping("/register")
    public ApiResponse<Map<String, Object>> register(@RequestBody Map<String, String> params) {
        String username = params.get("username");
        String password = params.get("password");
        String confirmPassword = params.get("confirmPassword");
        String nickname = params.getOrDefault("nickname", "");
        
        if (!password.equals(confirmPassword)) {
            return ApiResponse.error(400, "两次密码输入不一致");
        }

        if (username == null || username.trim().isEmpty()) {
            return ApiResponse.error(400, "用户名不能为空");
        }

        if (password == null || password.length() < 6) {
            return ApiResponse.error(400, "密码长度不能少于6位");
        }

        try {
            User user = userService.register(username, password, nickname);
            Map<String, Object> result = new HashMap<>();
            result.put("id", user.getId());
            result.put("username", user.getUsername());
            result.put("nickname", user.getNickname());
            result.put("message", "注册成功，请登录");
            return ApiResponse.success(result);
        } catch (IllegalArgumentException e) {
            return ApiResponse.error(400, e.getMessage());
        } catch (Exception e) {
            return ApiResponse.error(500, "注册失败：" + e.getMessage());
        }
    }

    @PostMapping("/login")
    public ApiResponse<Map<String, Object>> login(@RequestBody Map<String, String> params) {
        String username = params.get("username");
        String password = params.get("password");
        
        if (username == null || username.trim().isEmpty() || password == null || password.trim().isEmpty()) {
            return ApiResponse.error(400, "用户名或密码不能为空");
        }

        try {
            Map<String, Object> result = userService.login(username, password);
            return ApiResponse.success(result);
        } catch (IllegalArgumentException e) {
            return ApiResponse.error(401, e.getMessage());
        } catch (Exception e) {
            return ApiResponse.error(500, "登录失败：" + e.getMessage());
        }
    }

    @GetMapping("/verify")
    public ApiResponse<Map<String, Object>> verifyToken(@RequestHeader("Authorization") String token) {
        if (token == null || token.isEmpty()) {
            return ApiResponse.error(401, "未携带token");
        }

        try {
            Map<String, Object> result = userService.verifyToken(token);
            return ApiResponse.success(result);
        } catch (IllegalArgumentException e) {
            return ApiResponse.error(401, e.getMessage());
        }
    }
}