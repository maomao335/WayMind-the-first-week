package com.studymate.rag.service;

import com.studymate.rag.entity.DocumentVector;

import java.util.List;

public interface DocumentVectorService {

    List<DocumentVector> createVectors(Long documentId, String content);

    List<DocumentVector> getByDocumentId(Long documentId);

    List<DocumentVector> getByUserId(Long userId);

    DocumentVector getById(Long id);

    void deleteByDocumentId(Long documentId);

    void deleteById(Long id);

    int countByDocumentId(Long documentId);

    List<DocumentVector> getAll();
}