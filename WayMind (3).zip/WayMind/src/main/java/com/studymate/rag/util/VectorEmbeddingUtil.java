package com.studymate.rag.util;

import org.springframework.stereotype.Component;

import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Component
public class VectorEmbeddingUtil {

    private static final int DEFAULT_VECTOR_DIM = 64;
    private static final int MAX_VOCABULARY_SIZE = 10000;
    private static final Pattern WORD_PATTERN = Pattern.compile("[\\u4e00-\\u9fa5]{2,}|[a-zA-Z]+");

    private final Map<String, Integer> globalVocabulary = new HashMap<>();
    private final Random random = new Random(42);

    public VectorEmbeddingUtil() {
        initializeDefaultVocabulary();
    }

    private void initializeDefaultVocabulary() {
        String[] defaultWords = {
                "请假", "报销", "选课", "补助", "申请", "流程", "政策", "规定",
                "学生", "教师", "员工", "部门", "学校", "公司", "单位",
                "课程", "成绩", "考试", "作业", "论文", "答辩",
                "费用", "发票", "金额", "标准", "审批", "提交",
                "时间", "截止", "期限", "要求", "材料", "证明",
                "系统", "平台", "网站", "登录", "注册", "查询",
                "通知", "公告", "说明", "指南", "帮助", "常见问题"
        };
        for (int i = 0; i < defaultWords.length; i++) {
            globalVocabulary.put(defaultWords[i], i);
        }
    }

    public double[] generateEmbedding(String text) {
        return generateEmbedding(text, DEFAULT_VECTOR_DIM);
    }

    public double[] generateEmbedding(String text, int dim) {
        if (text == null || text.isEmpty()) {
            return new double[dim];
        }

        double[] vector = new double[dim];
        Arrays.fill(vector, 0.0);

        List<String> tokens = tokenize(text);
        if (tokens.isEmpty()) {
            return vector;
        }

        Map<String, Integer> wordCount = new HashMap<>();
        for (String token : tokens) {
            wordCount.put(token, wordCount.getOrDefault(token, 0) + 1);
        }

        for (String word : tokens) {
            int hash = getWordHash(word);
            int idx = Math.abs(hash) % dim;
            double tf = (double) wordCount.get(word) / tokens.size();
            double idf = calculateIDF(word, tokens.size());
            vector[idx] += tf * idf;
        }

        vector = addPositionEncoding(text, vector, dim);
        vector = normalize(vector);

        return vector;
    }

    private List<String> tokenize(String text) {
        List<String> tokens = new ArrayList<>();
        Matcher matcher = WORD_PATTERN.matcher(text);

        while (matcher.find()) {
            String word = matcher.group().trim();
            if (word.length() >= 2 && !isStopWord(word)) {
                tokens.add(word.toLowerCase());
                if (!globalVocabulary.containsKey(word) && globalVocabulary.size() < MAX_VOCABULARY_SIZE) {
                    globalVocabulary.put(word, globalVocabulary.size());
                }
            }
        }

        return tokens;
    }

    private int getWordHash(String word) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] hashBytes = md.digest(word.getBytes(StandardCharsets.UTF_8));
            BigInteger bigInt = new BigInteger(1, hashBytes);
            return bigInt.intValue();
        } catch (NoSuchAlgorithmException e) {
            return word.hashCode();
        }
    }

    private double calculateIDF(String word, int totalDocuments) {
        int docCount = globalVocabulary.containsKey(word) ? 1 : 0;
        return Math.log((double) (totalDocuments + 1) / (docCount + 1)) + 1;
    }

    private double[] addPositionEncoding(String text, double[] vector, int dim) {
        int textLength = text.length();
        for (int i = 0; i < Math.min(dim, textLength); i++) {
            double posValue = Math.sin((double) i / Math.pow(10000, 2.0 * i / dim));
            vector[i % dim] += posValue * 0.1;
        }
        return vector;
    }

    private double[] normalize(double[] vector) {
        double norm = 0;
        for (double v : vector) {
            norm += v * v;
        }
        norm = Math.sqrt(norm);
        if (norm > 0) {
            for (int i = 0; i < vector.length; i++) {
                vector[i] /= norm;
            }
        }
        return vector;
    }

    public double cosineSimilarity(double[] v1, double[] v2) {
        if (v1 == null || v2 == null || v1.length != v2.length) {
            return 0.0;
        }
        double dotProduct = 0;
        double norm1 = 0;
        double norm2 = 0;
        for (int i = 0; i < v1.length; i++) {
            dotProduct += v1[i] * v2[i];
            norm1 += v1[i] * v1[i];
            norm2 += v2[i] * v2[i];
        }
        norm1 = Math.sqrt(norm1);
        norm2 = Math.sqrt(norm2);
        if (norm1 == 0 || norm2 == 0) {
            return 0.0;
        }
        return dotProduct / (norm1 * norm2);
    }

    public String vectorToString(double[] vector) {
        if (vector == null) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < vector.length; i++) {
            if (i > 0) {
                sb.append(",");
            }
            sb.append(String.format("%.6f", vector[i]));
        }
        return sb.toString();
    }

    public double[] stringToVector(String vectorStr) {
        if (vectorStr == null || vectorStr.isEmpty()) {
            return new double[DEFAULT_VECTOR_DIM];
        }
        String[] parts = vectorStr.split(",");
        double[] vector = new double[parts.length];
        for (int i = 0; i < parts.length; i++) {
            try {
                vector[i] = Double.parseDouble(parts[i].trim());
            } catch (NumberFormatException e) {
                vector[i] = 0.0;
            }
        }
        return vector;
    }

    private boolean isStopWord(String word) {
        Set<String> stopWords = new HashSet<>(Arrays.asList(
                "的", "了", "在", "是", "我", "有", "和", "就", "不", "人", "都", "一", "一个", "上", "也", "很", "到", "说", "要", "去", "你", "会", "着", "没有", "看", "好", "自己",
                "这", "那", "这个", "那个", "这些", "那些", "什么", "怎么", "如何", "为什么", "因为", "所以", "但是", "如果", "虽然", "还是", "或者", "以及", "等等",
                "可以", "可能", "应该", "必须", "需要", "已经", "正在", "曾经", "将要", "能够", "愿意", "应该", "会", "想", "希望", "打算", "觉得", "认为", "知道", "了解", "明白",
                "通过", "经过", "根据", "按照", "关于", "对于", "至于", "由于", "鉴于", "为了", "以便", "以免", "否则", "要么", "只要", "只有", "除非", "无论", "不管", "尽管", "即使",
                "一些", "有些", "若干", "许多", "大量", "部分", "全部", "所有", "任何", "每一个", "每个", "各自", "互相", "彼此", "对方", "别人", "他人", "大家", "人们", "群众",
                "时候", "时间", "地方", "地点", "方面", "情况", "状况", "状态", "问题", "事情", "事件", "现象", "结果", "原因", "理由", "目的", "目标", "方向", "方式", "方法", "途径",
                "点", "次", "回", "遍", "趟", "顿", "份", "个", "位", "名", "本", "件", "条", "张", "块", "元", "斤", "两", "米", "厘米", "毫米", "千克", "克", "吨", "小时", "分钟", "秒",
                "a", "an", "the", "is", "are", "was", "were", "be", "been", "being", "have", "has", "had", "do", "does", "did", "will", "would", "could", "should", "may", "might", "must", "shall", "can"
        ));
        return stopWords.contains(word);
    }

    public int getDefaultVectorDim() {
        return DEFAULT_VECTOR_DIM;
    }
}