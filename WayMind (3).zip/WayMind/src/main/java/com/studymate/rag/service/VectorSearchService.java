package com.studymate.rag.service;

import com.studymate.rag.entity.DocumentVector;
import com.studymate.rag.mapper.DocumentVectorMapper;
import com.studymate.rag.util.VectorEmbeddingUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class VectorSearchService {

    @Autowired
    private DocumentVectorMapper documentVectorMapper;

    @Autowired
    private VectorEmbeddingUtil vectorEmbeddingUtil;

    public List<DocumentVector> searchSimilar(String query, int topN) {
        return searchSimilar(query, topN, null);
    }

    public List<DocumentVector> searchSimilar(String query, int topN, Long userId) {
        if (query == null || query.isEmpty()) {
            return Collections.emptyList();
        }

        double[] queryVector = vectorEmbeddingUtil.generateEmbedding(query);

        List<DocumentVector> allVectors;
        if (userId != null) {
            allVectors = documentVectorMapper.selectByUserId(userId);
        } else {
            allVectors = documentVectorMapper.selectRecent(1000);
        }

        if (allVectors.isEmpty()) {
            return Collections.emptyList();
        }

        List<SimilarityResult> results = new ArrayList<>();

        for (DocumentVector vector : allVectors) {
            double[] docVector = vectorEmbeddingUtil.stringToVector(vector.getVectorData());
            double similarity = vectorEmbeddingUtil.cosineSimilarity(queryVector, docVector);
            results.add(new SimilarityResult(vector, similarity));
        }

        results.sort((a, b) -> Double.compare(b.similarity, a.similarity));

        List<DocumentVector> topResults = new ArrayList<>();
        for (int i = 0; i < Math.min(topN, results.size()); i++) {
            if (results.get(i).similarity > 0.01) {
                topResults.add(results.get(i).vector);
            }
        }

        return topResults;
    }

    public String buildContextFromResults(List<DocumentVector> results) {
        if (results == null || results.isEmpty()) {
            return "";
        }

        StringBuilder context = new StringBuilder();
        context.append("【参考文档内容】\n\n");

        for (int i = 0; i < results.size(); i++) {
            DocumentVector dv = results.get(i);
            context.append(String.format("文档片段 %d：\n", i + 1));
            context.append(dv.getChunkText());
            context.append("\n\n");
        }

        context.append("【以上内容仅供参考，请结合用户问题进行回答】");
        return context.toString();
    }

    public List<String> searchSimilarChunks(String query, int topN) {
        List<DocumentVector> results = searchSimilar(query, topN);
        List<String> chunks = new ArrayList<>();
        for (DocumentVector dv : results) {
            chunks.add(dv.getChunkText());
        }
        return chunks;
    }

    private static class SimilarityResult {
        DocumentVector vector;
        double similarity;

        SimilarityResult(DocumentVector vector, double similarity) {
            this.vector = vector;
            this.similarity = similarity;
        }
    }
}