package com.studymate.rag.util;

import org.springframework.stereotype.Component;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Component
public class TextChunkUtil {

    private static final int DEFAULT_CHUNK_SIZE = 500;
    private static final int DEFAULT_OVERLAP_SIZE = 100;
    private static final Pattern SENTENCE_PATTERN = Pattern.compile("[。！？；.!?;]+");
    private static final Pattern PARAGRAPH_PATTERN = Pattern.compile("\\n\\s*\\n");
    private static final Pattern WORD_PATTERN = Pattern.compile("[\\u4e00-\\u9fa5]{2,}|[a-zA-Z]+");

    public List<String> splitText(String content) {
        return splitText(content, DEFAULT_CHUNK_SIZE, DEFAULT_OVERLAP_SIZE);
    }

    public List<String> splitText(String content, int chunkSize, int overlapSize) {
        if (content == null || content.isEmpty()) {
            return Collections.emptyList();
        }

        content = content.replaceAll("\\r\\n", "\n").replaceAll("\\r", "\n");

        List<String> paragraphs = splitByParagraph(content);
        List<String> chunks = new ArrayList<>();

        StringBuilder currentChunk = new StringBuilder();

        for (String paragraph : paragraphs) {
            paragraph = paragraph.trim();
            if (paragraph.isEmpty()) {
                continue;
            }

            if (currentChunk.length() + paragraph.length() <= chunkSize) {
                if (currentChunk.length() > 0) {
                    currentChunk.append("\n");
                }
                currentChunk.append(paragraph);
            } else {
                if (currentChunk.length() > 0) {
                    chunks.add(currentChunk.toString().trim());
                }

                List<String> sentences = splitBySentence(paragraph);
                StringBuilder tempChunk = new StringBuilder();

                for (String sentence : sentences) {
                    sentence = sentence.trim();
                    if (sentence.isEmpty()) {
                        continue;
                    }

                    if (tempChunk.length() + sentence.length() <= chunkSize) {
                        if (tempChunk.length() > 0) {
                            tempChunk.append("");
                        }
                        tempChunk.append(sentence);
                    } else {
                        if (tempChunk.length() > 0) {
                            chunks.add(tempChunk.toString().trim());
                            String overlap = tempChunk.substring(Math.max(0, tempChunk.length() - overlapSize));
                            tempChunk = new StringBuilder(overlap);
                        }
                        if (sentence.length() > chunkSize) {
                            chunks.addAll(splitByLength(sentence, chunkSize, overlapSize));
                            continue;
                        }
                        tempChunk.append(sentence);
                    }
                }

                if (tempChunk.length() > 0) {
                    currentChunk = tempChunk;
                }
            }
        }

        if (currentChunk.length() > 0) {
            chunks.add(currentChunk.toString().trim());
        }

        return chunks;
    }

    private List<String> splitByParagraph(String content) {
        Matcher matcher = PARAGRAPH_PATTERN.matcher(content);
        List<String> paragraphs = new ArrayList<>();
        int lastEnd = 0;

        while (matcher.find()) {
            String paragraph = content.substring(lastEnd, matcher.start()).trim();
            if (!paragraph.isEmpty()) {
                paragraphs.add(paragraph);
            }
            lastEnd = matcher.end();
        }

        String lastParagraph = content.substring(lastEnd).trim();
        if (!lastParagraph.isEmpty()) {
            paragraphs.add(lastParagraph);
        }

        return paragraphs;
    }

    private List<String> splitBySentence(String text) {
        Matcher matcher = SENTENCE_PATTERN.matcher(text);
        List<String> sentences = new ArrayList<>();
        int lastEnd = 0;

        while (matcher.find()) {
            String sentence = text.substring(lastEnd, matcher.end()).trim();
            if (!sentence.isEmpty()) {
                sentences.add(sentence);
            }
            lastEnd = matcher.end();
        }

        String lastSentence = text.substring(lastEnd).trim();
        if (!lastSentence.isEmpty()) {
            sentences.add(lastSentence);
        }

        return sentences;
    }

    private List<String> splitByLength(String text, int chunkSize, int overlapSize) {
        List<String> chunks = new ArrayList<>();
        int start = 0;

        while (start < text.length()) {
            int end = Math.min(start + chunkSize, text.length());
            chunks.add(text.substring(start, end).trim());
            start = end - overlapSize;
            if (start <= 0) {
                start = end;
            }
        }

        return chunks;
    }

    public List<String> extractKeywords(String text, int topN) {
        if (text == null || text.isEmpty()) {
            return Collections.emptyList();
        }

        Map<String, Integer> wordCount = new HashMap<>();
        Matcher matcher = WORD_PATTERN.matcher(text);

        while (matcher.find()) {
            String word = matcher.group().trim().toLowerCase();
            if (word.length() >= 2 && !isStopWord(word)) {
                wordCount.put(word, wordCount.getOrDefault(word, 0) + 1);
            }
        }

        List<Map.Entry<String, Integer>> sortedWords = new ArrayList<>(wordCount.entrySet());
        sortedWords.sort((a, b) -> b.getValue().compareTo(a.getValue()));

        List<String> keywords = new ArrayList<>();
        for (int i = 0; i < Math.min(topN, sortedWords.size()); i++) {
            keywords.add(sortedWords.get(i).getKey());
        }

        return keywords;
    }

    private boolean isStopWord(String word) {
        Set<String> stopWords = new HashSet<>(Arrays.asList(
                "的", "了", "在", "是", "我", "有", "和", "就", "不", "人", "都", "一", "一个", "上", "也", "很", "到", "说", "要", "去", "你", "会", "着", "没有", "看", "好", "自己",
                "这", "那", "这个", "那个", "这些", "那些", "什么", "怎么", "如何", "为什么", "因为", "所以", "但是", "如果", "虽然", "还是", "或者", "以及", "等等",
                "可以", "可能", "应该", "必须", "需要", "已经", "正在", "曾经", "将要", "能够", "愿意", "应该", "会", "想", "希望", "打算", "觉得", "认为", "知道", "了解", "明白",
                "通过", "经过", "根据", "按照", "关于", "对于", "至于", "由于", "鉴于", "为了", "以便", "以免", "否则", "要么", "只要", "只有", "除非", "无论", "不管", "尽管", "即使",
                "一些", "有些", "若干", "许多", "大量", "部分", "全部", "所有", "任何", "每一个", "每个", "各自", "互相", "彼此", "对方", "别人", "他人", "大家", "人们", "群众",
                "时候", "时间", "地方", "地点", "方面", "情况", "状况", "状态", "问题", "事情", "事件", "现象", "结果", "原因", "理由", "目的", "目标", "方向", "方式", "方法", "途径",
                "点", "次", "回", "遍", "趟", "顿", "份", "个", "位", "名", "本", "件", "条", "张", "块", "元", "斤", "两", "米", "厘米", "毫米", "千克", "克", "吨", "小时", "分钟", "秒",
                "a", "an", "the", "is", "are", "was", "were", "be", "been", "being", "have", "has", "had", "do", "does", "did", "will", "would", "could", "should", "may", "might", "must", "shall", "can"
        ));
        return stopWords.contains(word);
    }

    public String generateChunkSummary(String chunkText) {
        if (chunkText == null || chunkText.isEmpty()) {
            return "";
        }
        if (chunkText.length() <= 100) {
            return chunkText;
        }
        return chunkText.substring(0, 100) + "...";
    }
}