package com.studymate.rag.service.impl;

import com.studymate.rag.entity.DocumentVector;
import com.studymate.rag.mapper.DocumentVectorMapper;
import com.studymate.rag.service.DocumentVectorService;
import com.studymate.rag.util.TextChunkUtil;
import com.studymate.rag.util.VectorEmbeddingUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Service
public class DocumentVectorServiceImpl implements DocumentVectorService {

    @Autowired
    private DocumentVectorMapper documentVectorMapper;

    @Autowired
    private TextChunkUtil textChunkUtil;

    @Autowired
    private VectorEmbeddingUtil vectorEmbeddingUtil;

    private static final int MAX_CONTENT_LENGTH = 200000;
    private static final int MAX_CHUNK_COUNT = 50;

    @Override
    public List<DocumentVector> createVectors(Long documentId, String content) {
        deleteByDocumentId(documentId);

        if (content == null || content.isEmpty()) {
            return new ArrayList<>();
        }

        if (content.length() > MAX_CONTENT_LENGTH) {
            content = content.substring(0, MAX_CONTENT_LENGTH);
        }

        List<String> chunks = textChunkUtil.splitText(content);
        if (chunks.size() > MAX_CHUNK_COUNT) {
            chunks = chunks.subList(0, MAX_CHUNK_COUNT);
        }

        List<DocumentVector> vectors = new ArrayList<>();

        for (int i = 0; i < chunks.size(); i++) {
            String chunkText = chunks.get(i);
            if (chunkText.trim().isEmpty()) {
                continue;
            }

            double[] embedding = vectorEmbeddingUtil.generateEmbedding(chunkText);
            String vectorData = vectorEmbeddingUtil.vectorToString(embedding);
            List<String> keywords = textChunkUtil.extractKeywords(chunkText, 5);
            String chunkSummary = textChunkUtil.generateChunkSummary(chunkText);

            DocumentVector dv = new DocumentVector();
            dv.setDocumentId(documentId);
            dv.setChunkIndex(i);
            dv.setChunkText(chunkText);
            dv.setChunkSummary(chunkSummary);
            dv.setVectorDim(embedding.length);
            dv.setVectorData(vectorData);
            dv.setKeywords(String.join(",", keywords));
            dv.setCreatedAt(LocalDateTime.now());
            dv.setUpdatedAt(LocalDateTime.now());

            documentVectorMapper.insert(dv);
            vectors.add(dv);
        }

        return vectors;
    }

    @Override
    public List<DocumentVector> getByDocumentId(Long documentId) {
        return documentVectorMapper.selectByDocumentId(documentId);
    }

    @Override
    public List<DocumentVector> getByUserId(Long userId) {
        return documentVectorMapper.selectByUserId(userId);
    }

    @Override
    public DocumentVector getById(Long id) {
        return documentVectorMapper.selectById(id);
    }

    @Override
    @Transactional
    public void deleteByDocumentId(Long documentId) {
        documentVectorMapper.deleteByDocumentId(documentId);
    }

    @Override
    @Transactional
    public void deleteById(Long id) {
        documentVectorMapper.deleteById(id);
    }

    @Override
    public int countByDocumentId(Long documentId) {
        return documentVectorMapper.countByDocumentId(documentId);
    }

    @Override
    public List<DocumentVector> getAll() {
        return documentVectorMapper.selectRecent(1000);
    }
}