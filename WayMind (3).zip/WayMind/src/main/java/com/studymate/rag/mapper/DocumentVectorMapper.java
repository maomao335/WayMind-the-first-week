package com.studymate.rag.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.studymate.rag.entity.DocumentVector;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface DocumentVectorMapper extends BaseMapper<DocumentVector> {

    @Select("SELECT * FROM document_vector WHERE document_id = #{documentId} ORDER BY chunk_index")
    List<DocumentVector> selectByDocumentId(Long documentId);

    @Select("SELECT * FROM document_vector WHERE document_id = #{documentId}")
    List<DocumentVector> getByDocumentId(Long documentId);

    @Select("SELECT * FROM document_vector ORDER BY created_at DESC LIMIT #{limit}")
    List<DocumentVector> selectRecent(int limit);

    @Select("SELECT dv.* FROM document_vector dv JOIN document d ON dv.document_id = d.id WHERE d.user_id = #{userId} ORDER BY dv.created_at DESC")
    List<DocumentVector> selectByUserId(Long userId);

    @Delete("DELETE FROM document_vector WHERE document_id = #{documentId}")
    int deleteByDocumentId(Long documentId);

    @Select("SELECT COUNT(*) FROM document_vector WHERE document_id = #{documentId}")
    int countByDocumentId(Long documentId);
}