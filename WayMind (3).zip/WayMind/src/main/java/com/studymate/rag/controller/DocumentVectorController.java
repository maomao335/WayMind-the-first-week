package com.studymate.rag.controller;

import com.studymate.dto.ApiResponse;
import com.studymate.rag.entity.DocumentVector;
import com.studymate.rag.service.DocumentVectorService;
import com.studymate.rag.service.VectorSearchService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/rag")
@CrossOrigin(origins = "*")
public class DocumentVectorController {

    @Autowired
    private DocumentVectorService documentVectorService;

    @Autowired
    private VectorSearchService vectorSearchService;

    @GetMapping("/vectors")
    public ApiResponse<List<DocumentVector>> getAllVectors() {
        List<DocumentVector> vectors = documentVectorService.getAll();
        return ApiResponse.success(vectors);
    }

    @GetMapping("/vectors/document/{documentId}")
    public ApiResponse<List<DocumentVector>> getVectorsByDocument(@PathVariable Long documentId) {
        List<DocumentVector> vectors = documentVectorService.getByDocumentId(documentId);
        return ApiResponse.success(vectors);
    }

    @GetMapping("/vectors/user/{userId}")
    public ApiResponse<List<DocumentVector>> getVectorsByUser(@PathVariable Long userId) {
        List<DocumentVector> vectors = documentVectorService.getByUserId(userId);
        return ApiResponse.success(vectors);
    }

    @GetMapping("/vectors/{id}")
    public ApiResponse<DocumentVector> getVectorById(@PathVariable Long id) {
        DocumentVector vector = documentVectorService.getById(id);
        if (vector == null) {
            return ApiResponse.error("Vector not found");
        }
        return ApiResponse.success(vector);
    }

    @DeleteMapping("/vectors/{id}")
    public ApiResponse<Void> deleteVector(@PathVariable Long id) {
        documentVectorService.deleteById(id);
        return ApiResponse.success(null);
    }

    @DeleteMapping("/vectors/document/{documentId}")
    public ApiResponse<Void> deleteVectorsByDocument(@PathVariable Long documentId) {
        documentVectorService.deleteByDocumentId(documentId);
        return ApiResponse.success(null);
    }

    @GetMapping("/search")
    public ApiResponse<List<DocumentVector>> searchSimilar(
            @RequestParam String query,
            @RequestParam(defaultValue = "3") int topN,
            @RequestParam(required = false) Long userId) {
        List<DocumentVector> results = vectorSearchService.searchSimilar(query, topN, userId);
        return ApiResponse.success(results);
    }

    @GetMapping("/search/context")
    public ApiResponse<Map<String, Object>> searchWithContext(
            @RequestParam String query,
            @RequestParam(defaultValue = "3") int topN,
            @RequestParam(required = false) Long userId) {
        List<DocumentVector> results = vectorSearchService.searchSimilar(query, topN, userId);
        String context = vectorSearchService.buildContextFromResults(results);

        Map<String, Object> response = new HashMap<>();
        response.put("results", results);
        response.put("context", context);
        response.put("matchCount", results.size());

        return ApiResponse.success(response);
    }

    @GetMapping("/stats")
    public ApiResponse<Map<String, Object>> getStats() {
        List<DocumentVector> allVectors = documentVectorService.getAll();
        
        Map<String, Object> stats = new HashMap<>();
        stats.put("totalVectors", allVectors.size());
        
        Map<Long, Integer> docCountMap = new HashMap<>();
        for (DocumentVector dv : allVectors) {
            docCountMap.put(dv.getDocumentId(), docCountMap.getOrDefault(dv.getDocumentId(), 0) + 1);
        }
        stats.put("documentCount", docCountMap.size());
        stats.put("vectorsPerDocument", docCountMap);

        return ApiResponse.success(stats);
    }
}