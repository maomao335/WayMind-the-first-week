package com.studymate.service.impl;

import com.studymate.dto.SkillResponse;
import com.studymate.entity.Document;
import com.studymate.mapper.DocumentMapper;
import com.studymate.rag.service.DocumentVectorService;
import com.studymate.service.FileParseService;
import com.studymate.util.DocumentParserUtil;
import com.studymate.util.QianWenClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.LocalDateTime;

@Service
public class FileParseServiceImpl implements FileParseService {

    @Autowired
    private DocumentParserUtil documentParserUtil;

    @Autowired
    private DocumentMapper documentMapper;

    @Autowired
    private QianWenClient qianWenClient;

    @Autowired
    private DocumentVectorService documentVectorService;

    @Override
    public SkillResponse parseFile(Long userId, MultipartFile file) {
        if (file == null || file.isEmpty()) {
            throw new IllegalArgumentException("File cannot be empty");
        }

        String fileName = file.getOriginalFilename();
        if (!DocumentParserUtil.isAllowedFileType(fileName)) {
            throw new IllegalArgumentException("Unsupported file type. Only PDF, DOC, DOCX are allowed");
        }

        long fileSize = file.getSize();
        if (fileSize > 10 * 1024 * 1024) {
            throw new IllegalArgumentException("File size exceeds 10MB limit");
        }

        String content;
        try {
            content = documentParserUtil.parseDocument(file);
        } catch (IOException e) {
            throw new RuntimeException("Failed to parse document", e);
        }

        String fileType = DocumentParserUtil.getFileExtension(fileName);
        String summary = generateSummary(content);

        Document document = new Document();
        document.setUserId(userId);
        document.setFileName(fileName);
        document.setFileType(fileType);
        document.setFileSize(fileSize);
        document.setContent(content);
        document.setSummary(summary);
        document.setCreatedAt(LocalDateTime.now());
        document.setUpdatedAt(LocalDateTime.now());
        documentMapper.insert(document);

        documentVectorService.createVectors(document.getId(), content);

        SkillResponse response = new SkillResponse();
        response.setResult("文件解析成功");

        SkillResponse.DocumentInfo docInfo = new SkillResponse.DocumentInfo();
        docInfo.setId(document.getId());
        docInfo.setFileName(fileName);
        docInfo.setFileType(fileType);
        docInfo.setFileSize(fileSize);
        docInfo.setContent(content);
        docInfo.setSummary(summary);
        response.setDocument(docInfo);

        return response;
    }

    private String generateSummary(String content) {
        if (content == null || content.isEmpty()) {
            return "";
        }
        String truncatedContent = content;
        if (content.length() > 8000) {
            truncatedContent = content.substring(0, 8000) + "...";
        }
        String prompt = "请帮我总结以下文档的核心内容，提取重点信息，用清晰的结构呈现：\n\n" + truncatedContent;
        try {
            return qianWenClient.chat(prompt);
        } catch (IOException e) {
            if (content.length() <= 1000) {
                return content;
            }
            return content.substring(0, 1000) + "...";
        }
    }
}