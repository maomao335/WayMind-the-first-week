package com.studymate.service.impl;

import com.studymate.dto.SkillResponse;
import com.studymate.service.DialogClarifyService;
import com.studymate.util.IntentRecognizerUtil;
import com.studymate.util.QianWenClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.regex.Pattern;

@Service
public class DialogClarifyServiceImpl implements DialogClarifyService {

    @Autowired
    private IntentRecognizerUtil intentRecognizerUtil;

    @Autowired
    private QianWenClient qianWenClient;

    private static final Pattern VAGUE_PATTERN = Pattern.compile(
        "^(怎么|如何|怎样|如何办理|怎么办|有什么|什么是|什么)$", 
        Pattern.CASE_INSENSITIVE
    );
    
    private static final Pattern VAGUE_PHRASE_PATTERN = Pattern.compile(
        "(怎么办理|如何办理|怎么办|有什么|什么是|有哪些|怎么弄|怎样做|如何做)",
        Pattern.CASE_INSENSITIVE
    );
    
    private static final Pattern CAMPUS_CARD_PATTERN = Pattern.compile("校园卡|饭卡|充值|余额|消费", Pattern.CASE_INSENSITIVE);
    private static final Pattern HOLIDAY_PATTERN = Pattern.compile("放假|假期|国庆|中秋|元旦|放假安排", Pattern.CASE_INSENSITIVE);
    private static final Pattern ADMISSION_PATTERN = Pattern.compile("招生|录取|报考|入学|招生简章|录取分数线|志愿填报", Pattern.CASE_INSENSITIVE);
    private static final Pattern DOC_QA_PATTERN = Pattern.compile("文档|文件|内容|摘要", Pattern.CASE_INSENSITIVE);
    private static final Pattern CHAT_PATTERN = Pattern.compile("你好|嗨|在吗|聊聊天|随便说说|最近怎么样", Pattern.CASE_INSENSITIVE);

    @Override
    public SkillResponse clarify(Long userId, String message) {
        if (message == null || message.trim().isEmpty()) {
            throw new IllegalArgumentException("Message cannot be empty");
        }

        IntentRecognizerUtil.SceneType sceneType = intentRecognizerUtil.recognize(message);

        SkillResponse response = new SkillResponse();
        response.setSceneType(sceneType.getCode());
        response.setSceneName(sceneType.getName());

        if (!needsClarification(message, sceneType)) {
            response.setResult("");
            return response;
        }

        String clarifyPrompt = buildClarifyPrompt(message, sceneType);
        String aiResponse;
        try {
            aiResponse = qianWenClient.chat(clarifyPrompt);
        } catch (IOException e) {
            throw new RuntimeException("Failed to call QianWen API", e);
        }
        response.setResult(aiResponse);

        return response;
    }

    private boolean needsClarification(String message, IntentRecognizerUtil.SceneType sceneType) {
        String trimmed = message.trim();
        
        if (sceneType != IntentRecognizerUtil.SceneType.OTHER) {
            return false;
        }

        if (CAMPUS_CARD_PATTERN.matcher(trimmed).find()) {
            return false;
        }
        
        if (HOLIDAY_PATTERN.matcher(trimmed).find()) {
            return false;
        }
        
        if (ADMISSION_PATTERN.matcher(trimmed).find()) {
            return false;
        }
        
        if (DOC_QA_PATTERN.matcher(trimmed).find()) {
            return false;
        }
        
        if (CHAT_PATTERN.matcher(trimmed).find()) {
            return false;
        }

        if (trimmed.length() <= 5) {
            return true;
        }

        if (VAGUE_PATTERN.matcher(trimmed).matches()) {
            return true;
        }

        if (VAGUE_PHRASE_PATTERN.matcher(trimmed).find()) {
            String[] words = trimmed.split("[\\s,，。？！]");
            return words.length < 8;
        }

        return false;
    }

    private String buildClarifyPrompt(String message, IntentRecognizerUtil.SceneType sceneType) {
        String scenePrompt;
        switch (sceneType) {
            case LEAVE:
                scenePrompt = "这是一个请假相关的问题，请询问用户以下信息：请假类型（事假/病假/年假等）、请假时间（开始日期、结束日期）、请假原因。";
                break;
            case REIMBURSE:
                scenePrompt = "这是一个报销相关的问题，请询问用户以下信息：报销类型（差旅/办公用品/其他）、报销金额、报销事由、是否有发票。";
                break;
            case COURSE:
                scenePrompt = "这是一个选课相关的问题，请询问用户以下信息：所在年级/专业、意向课程类型、时间安排偏好。";
                break;
            case SUBSIDY:
                scenePrompt = "这是一个补助相关的问题，请询问用户以下信息：补助类型（助学金/奖学金/生活补助）、申请条件是否满足、是否已准备相关材料。";
                break;
            case ADMISSION:
                scenePrompt = "这是一个招生相关的问题，请询问用户以下信息：报考类型（本科/研究生）、意向专业、所在省份/地区。";
                break;
            default:
                scenePrompt = "用户的问题比较模糊，请友好地询问用户具体想了解哪方面的信息，比如：校园卡、选课、招生、请假、报销等。";
        }

        return String.format("用户说：\"%s\"。%s 请用友好、简洁的方式向用户提问，获取必要信息以便更好地帮助用户。", message, scenePrompt);
    }
}