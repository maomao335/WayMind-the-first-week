package com.studymate.service.impl;

import com.studymate.agent.service.AgentCoreService;
import com.studymate.dto.ChatRequest;
import com.studymate.dto.ChatResponse;
import com.studymate.entity.Conversation;
import com.studymate.entity.ChatHistory;
import com.studymate.mapper.ChatHistoryMapper;
import com.studymate.mapper.ConversationMapper;
import com.studymate.service.ChatService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Service
public class ChatServiceImpl implements ChatService {

    @Autowired
    private ChatHistoryMapper chatHistoryMapper;

    @Autowired
    private ConversationMapper conversationMapper;

    @Autowired
    private AgentCoreService agentCoreService;

    @Autowired
    private ObjectMapper objectMapper;

    private static final int CONTEXT_ROUNDS = 20;

    @Override
    @Transactional
    public ChatResponse sendMessage(ChatRequest request) {
        if (request.getMessage() == null || request.getMessage().trim().isEmpty()) {
            throw new IllegalArgumentException("Message cannot be empty");
        }

        Long userId = request.getUserId();
        if (userId == null) {
            throw new IllegalArgumentException("用户未登录");
        }

        Long conversationId = request.getConversationId();
        Conversation conversation = null;
        
        if (conversationId != null) {
            conversation = conversationMapper.selectByIdAndUserId(conversationId, userId);
            if (conversation == null) {
                conversation = createConversation(userId);
                conversationId = conversation.getId();
            }
        } else {
            conversation = createConversation(userId);
            conversationId = conversation.getId();
        }

        String sessionId = conversation.getSessionId();
        if (sessionId == null || sessionId.isEmpty()) {
            sessionId = UUID.randomUUID().toString();
            conversation.setSessionId(sessionId);
            conversationMapper.updateById(conversation);
        }

        List<ChatHistory> recentMessages = chatHistoryMapper.selectRecentByConversationId(conversationId, userId, CONTEXT_ROUNDS * 2);
        
        String context = buildContext(recentMessages);
        
        ChatResponse response = agentCoreService.execute(userId, sessionId, request.getMessage(), context);
        response.setUserId(userId);
        response.setSessionId(sessionId);
        response.setConversationId(conversationId);

        String toolLogsJson = null;
        if (response.getToolLogs() != null && !response.getToolLogs().isEmpty()) {
            try {
                toolLogsJson = objectMapper.writeValueAsString(response.getToolLogs());
            } catch (JsonProcessingException e) {
                toolLogsJson = response.getToolLogs().toString();
            }
        }

        saveUserMessage(userId, conversationId, request.getMessage());
        
        if (toolLogsJson != null && !toolLogsJson.isEmpty()) {
            saveToolMessage(userId, conversationId, toolLogsJson);
        }
        
        saveAssistantMessage(userId, conversationId, response.getReply());

        int messageCount = chatHistoryMapper.countByConversationId(conversationId, userId);
        if (messageCount == 3) {
            String title = request.getMessage();
            if (title.length() > 15) {
                title = title.substring(0, 15) + "...";
            }
            conversation.setTitle(title);
        }
        conversation.setUpdatedAt(LocalDateTime.now());
        conversationMapper.updateById(conversation);

        return response;
    }

    private String buildContext(List<ChatHistory> messages) {
        StringBuilder context = new StringBuilder();
        if (messages == null || messages.isEmpty()) {
            return "";
        }
        
        for (int i = messages.size() - 1; i >= 0; i--) {
            ChatHistory msg = messages.get(i);
            if ("user".equals(msg.getRole())) {
                context.append("用户：").append(msg.getContent()).append("\n");
            } else if ("assistant".equals(msg.getRole())) {
                context.append("助手：").append(msg.getContent()).append("\n");
            }
        }
        
        return context.toString();
    }

    private Conversation createConversation(Long userId) {
        Conversation conversation = new Conversation();
        conversation.setUserId(userId);
        conversation.setTitle("新对话");
        conversation.setCreatedAt(LocalDateTime.now());
        conversation.setUpdatedAt(LocalDateTime.now());
        conversationMapper.insert(conversation);
        return conversation;
    }

    private void saveUserMessage(Long userId, Long conversationId, String content) {
        ChatHistory history = new ChatHistory();
        history.setUserId(userId);
        history.setConversationId(conversationId);
        history.setRole("user");
        history.setContent(content);
        history.setCreatedAt(LocalDateTime.now());
        chatHistoryMapper.insert(history);
    }

    private void saveAssistantMessage(Long userId, Long conversationId, String content) {
        ChatHistory history = new ChatHistory();
        history.setUserId(userId);
        history.setConversationId(conversationId);
        history.setRole("assistant");
        history.setContent(content);
        history.setCreatedAt(LocalDateTime.now());
        chatHistoryMapper.insert(history);
    }

    private void saveToolMessage(Long userId, Long conversationId, String toolLogs) {
        ChatHistory history = new ChatHistory();
        history.setUserId(userId);
        history.setConversationId(conversationId);
        history.setRole("tool");
        history.setContent("工具调用日志");
        history.setToolLogs(toolLogs);
        history.setCreatedAt(LocalDateTime.now());
        chatHistoryMapper.insert(history);
    }
}