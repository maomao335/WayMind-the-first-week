package com.studymate.service;

import com.studymate.entity.User;

import java.util.Map;

public interface UserService {

    User register(String username, String password, String nickname);

    Map<String, Object> login(String username, String password);

    Map<String, Object> verifyToken(String token);

    User findByUsername(String username);

    User findById(Long id);
}