package com.studymate.service;

import com.studymate.entity.Conversation;
import com.studymate.entity.ChatHistory;

import java.util.List;

public interface ConversationService {

    Conversation createConversation(Long userId);

    List<Conversation> listConversations(Long userId);

    Conversation getConversation(Long id, Long userId);

    Conversation updateTitle(Long id, Long userId, String title);

    void deleteConversation(Long id, Long userId);

    List<ChatHistory> getConversationMessages(Long conversationId, Long userId);

    List<ChatHistory> getRecentMessages(Long conversationId, Long userId, int limit);
}