package com.studymate.service.impl;

import com.studymate.entity.Conversation;
import com.studymate.entity.ChatHistory;
import com.studymate.mapper.ConversationMapper;
import com.studymate.mapper.ChatHistoryMapper;
import com.studymate.service.ConversationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class ConversationServiceImpl implements ConversationService {

    @Autowired
    private ConversationMapper conversationMapper;

    @Autowired
    private ChatHistoryMapper chatHistoryMapper;

    @Override
    public Conversation createConversation(Long userId) {
        Conversation conversation = new Conversation();
        conversation.setUserId(userId);
        conversation.setTitle("新对话");
        conversation.setCreatedAt(LocalDateTime.now());
        conversation.setUpdatedAt(LocalDateTime.now());
        conversationMapper.insert(conversation);
        return conversation;
    }

    @Override
    public List<Conversation> listConversations(Long userId) {
        return conversationMapper.selectByUserId(userId);
    }

    @Override
    public Conversation getConversation(Long id, Long userId) {
        return conversationMapper.selectByIdAndUserId(id, userId);
    }

    @Override
    public Conversation updateTitle(Long id, Long userId, String title) {
        Conversation conversation = conversationMapper.selectByIdAndUserId(id, userId);
        if (conversation == null) {
            throw new IllegalArgumentException("会话不存在或无权访问");
        }
        conversation.setTitle(title);
        conversation.setUpdatedAt(LocalDateTime.now());
        conversationMapper.updateById(conversation);
        return conversation;
    }

    @Override
    @Transactional
    public void deleteConversation(Long id, Long userId) {
        Conversation conversation = conversationMapper.selectByIdAndUserId(id, userId);
        if (conversation == null) {
            throw new IllegalArgumentException("会话不存在或无权访问");
        }
        conversationMapper.deleteById(id);
    }

    @Override
    public List<ChatHistory> getConversationMessages(Long conversationId, Long userId) {
        Conversation conversation = conversationMapper.selectByIdAndUserId(conversationId, userId);
        if (conversation == null) {
            throw new IllegalArgumentException("会话不存在或无权访问");
        }
        return chatHistoryMapper.selectByConversationId(conversationId, userId);
    }

    @Override
    public List<ChatHistory> getRecentMessages(Long conversationId, Long userId, int limit) {
        Conversation conversation = conversationMapper.selectByIdAndUserId(conversationId, userId);
        if (conversation == null) {
            throw new IllegalArgumentException("会话不存在或无权访问");
        }
        return chatHistoryMapper.selectRecentByConversationId(conversationId, userId, limit);
    }
}