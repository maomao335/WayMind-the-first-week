package com.studymate.dto;

import java.util.List;

public class ChatResponse {

    private String reply;
    private Long userId;
    private String sessionId;
    private Long conversationId;
    private List<ToolCallLog> toolLogs;

    public String getReply() {
        return reply;
    }

    public void setReply(String reply) {
        this.reply = reply;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getSessionId() {
        return sessionId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    public Long getConversationId() {
        return conversationId;
    }

    public void setConversationId(Long conversationId) {
        this.conversationId = conversationId;
    }

    public List<ToolCallLog> getToolLogs() {
        return toolLogs;
    }

    public void setToolLogs(List<ToolCallLog> toolLogs) {
        this.toolLogs = toolLogs;
    }

    public static class ToolCallLog {
        private String toolName;
        private String toolType;
        private boolean success;
        private String error;
        private String outputSummary;

        public String getToolName() {
            return toolName;
        }

        public void setToolName(String toolName) {
            this.toolName = toolName;
        }

        public String getToolType() {
            return toolType;
        }

        public void setToolType(String toolType) {
            this.toolType = toolType;
        }

        public boolean isSuccess() {
            return success;
        }

        public void setSuccess(boolean success) {
            this.success = success;
        }

        public String getError() {
            return error;
        }

        public void setError(String error) {
            this.error = error;
        }

        public String getOutputSummary() {
            return outputSummary;
        }

        public void setOutputSummary(String outputSummary) {
            this.outputSummary = outputSummary;
        }
    }
}