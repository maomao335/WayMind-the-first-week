package com.studymate.util;

import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

@Component
public class IntentRecognizerUtil {

    public enum SceneType {
        LEAVE("leave", "请假"),
        REIMBURSE("reimburse", "报销"),
        COURSE("course", "选课"),
        SUBSIDY("subsidy", "补助"),
        ADMISSION("admission", "招生"),
        OTHER("other", "其他");

        private final String code;
        private final String name;

        SceneType(String code, String name) {
            this.code = code;
            this.name = name;
        }

        public String getCode() {
            return code;
        }

        public String getName() {
            return name;
        }
    }

    private final Map<SceneType, Pattern[]> scenePatterns = new HashMap<>();

    public IntentRecognizerUtil() {
        scenePatterns.put(SceneType.LEAVE, new Pattern[]{
                Pattern.compile("请假|休假|事假|病假|年假|调休|请假流程|怎么请假", Pattern.CASE_INSENSITIVE),
                Pattern.compile("请假申请|请几天假|请假条|请假审批|事假申请|病假申请", Pattern.CASE_INSENSITIVE)
        });

        scenePatterns.put(SceneType.REIMBURSE, new Pattern[]{
                Pattern.compile("报销|报销流程|怎么报销|费用报销|报销单|差旅费", Pattern.CASE_INSENSITIVE),
                Pattern.compile("报销申请|报销审批|报销步骤|报销材料|报销标准", Pattern.CASE_INSENSITIVE)
        });

        scenePatterns.put(SceneType.COURSE, new Pattern[]{
                Pattern.compile("选课|选课流程|怎么选课|课程选择|选课程|课程表", Pattern.CASE_INSENSITIVE),
                Pattern.compile("选课系统|选课时间|选课步骤|退选课|课程注册|专业课", Pattern.CASE_INSENSITIVE)
        });

        scenePatterns.put(SceneType.SUBSIDY, new Pattern[]{
                Pattern.compile("补助|补贴|助学金|奖学金|困难补助|生活补助|学费减免", Pattern.CASE_INSENSITIVE),
                Pattern.compile("补助申请|补助流程|怎么申请补助|补助条件|助学金申请", Pattern.CASE_INSENSITIVE)
        });

        scenePatterns.put(SceneType.ADMISSION, new Pattern[]{
                Pattern.compile("招生|招生渠道|招生简章|招生办|招生信息|招生咨询", Pattern.CASE_INSENSITIVE),
                Pattern.compile("报名|报名流程|报考|录取|录取查询|新生入学", Pattern.CASE_INSENSITIVE)
        });
    }

    public SceneType recognize(String text) {
        if (text == null || text.trim().isEmpty()) {
            return SceneType.OTHER;
        }

        for (Map.Entry<SceneType, Pattern[]> entry : scenePatterns.entrySet()) {
            for (Pattern pattern : entry.getValue()) {
                if (pattern.matcher(text).find()) {
                    return entry.getKey();
                }
            }
        }

        return SceneType.OTHER;
    }

    public String getSceneName(String text) {
        return recognize(text).getName();
    }

    public String getSceneCode(String text) {
        return recognize(text).getCode();
    }
}