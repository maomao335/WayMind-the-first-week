# StudyMate v0.4 - 校园/职场RAG智能问答机器人

## 项目阶段说明

### v0.1 版本（第一周）- 基础对话能力

**定位**：最小可运行原型，仅具备基础对话AI能力

实现功能：
- 用户发送文本消息
- 调用通义千问API获取AI回复
- 持久化存储对话历史记录

### v0.2 版本（第二周）- 三大AI Skill能力

**定位**：在基础对话之上，新增三大独立AI Skill能力

新增功能：
- 📁 **文件解析Skill**：支持上传PDF/Word文档，解析内容并生成摘要
- 🔍 **对话澄清Skill**：识别模糊问题，自动追问补充信息，支持多轮对话
- 🔗 **链接生成Skill**：根据场景意图匹配相关办事链接

### v0.3 版本（第三周）- RAG+Agent+MCP能力

**定位**：在Skill基础上，实现RAG检索增强、Agent自动调度和MCP模拟服务

新增功能：
- 📚 **RAG向量知识库**：文件上传自动向量化，支持语义检索，自动注入上下文
- 🤖 **Agent自动调度**：ReAct智能体，自动识别意图、选择工具、执行多工具链
- 🔗 **MCP模拟服务**：模拟教务/财务第三方接口（放假通知、报销进度、选课余量、校园卡通知）
- 📊 **知识库管理面板**：展示文档列表、向量入库状态、支持删除操作
- 📋 **工具调用日志**：对话气泡中展示本次Agent调用的工具记录
- 🔐 **用户认证系统**：完整的用户注册、登录、JWT鉴权功能

### v0.4 版本（第四周）- 聊天记录持久存档+多会话管理

**定位**：在RAG/Agent基础上，实现完整的会话管理和聊天记录持久化

新增功能：
- 📜 **会话存档面板**：左侧边栏新增历史会话存档区域
- ✅ **多会话管理**：支持新建、切换、重命名、删除会话
- 💾 **聊天记录永久存档**：所有消息存入MySQL数据库，重启不丢失
- 🔒 **用户数据隔离**：A用户无法查看B用户的任何会话与聊天记录
- 🔄 **上下文连贯**：切换会话自动加载历史消息作为上下文
- 📝 **自动生成标题**：首条提问自动截取前15字作为会话标题
- ⚡ **上下文截断**：自动保留最近20轮，避免token超限

---

### 用户认证功能（v0.3新增）

**功能说明**：
- 用户注册：用户名、密码、昵称注册
- 用户登录：账号密码校验，返回JWT令牌
- 全局鉴权：除登录/注册接口外，所有业务接口需携带有效token
- 登录状态管理：token存入localStorage，自动携带Authorization请求头

**测试账号**：
| 用户名 | 密码 | 昵称 |
| :--- | :--- | :--- |
| admin | admin | 管理员 |
| student | student | 学生用户 |

---

## 环境准备

### 前置依赖

| 依赖项 | 版本要求 | 说明 |
| :--- | :--- | :--- |
| MySQL | 8.0+ | 数据库服务 |
| JDK | 17+（推荐21） | 后端运行环境 |
| Maven | 3.8+ | 项目构建工具 |
| 浏览器 | Chrome/Edge/Firefox | 前端访问 |

### 环境验证

```bash
# 验证JDK版本
java -version

# 验证Maven版本
mvn -v

# 验证MySQL服务状态
mysql -u root -p -e "SELECT VERSION();"
```

---

## 启动流程

### 第一步：创建数据库

使用具有 `CREATE DATABASE` 权限的MySQL账号执行：

```sql
CREATE DATABASE IF NOT EXISTS studymate DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

### 第二步：执行建表SQL

进入项目目录，执行建表脚本：

```bash
# Windows PowerShell
Get-Content -Raw src/main/resources/schema.sql | mysql.exe -u root -p studymate

# Linux/Mac
mysql -u root -p studymate < src/main/resources/schema.sql
```

或手动在MySQL客户端中执行 `src/main/resources/schema.sql` 文件内容。

> **v0.3新增**：脚本会自动创建 `document_vector` 向量分片表和 `agent_task_log` 工具执行日志表。

### 第三步：配置密钥

编辑 `src/main/resources/application.yml` 文件：

```yaml
server:
  port: 8080

spring:
  datasource:
    url: jdbc:mysql://localhost:3306/studymate?useUnicode=true&characterEncoding=utf8&serverTimezone=Asia/Shanghai
    username: your-db-username    # 替换为你的数据库用户名
    password: your-db-password    # 替换为你的数据库密码
  servlet:
    multipart:
      max-file-size: 10MB
      max-request-size: 10MB

qianwen:
  api-key: your-qianwen-api-key   # 替换为你的通义千问API Key
```

> **通义千问API Key获取**：访问阿里云DashScope控制台（https://dashscope.console.aliyun.com/）申请API Key。

### 第四步：启动后端服务

```bash
cd WayMind
mvn spring-boot:run
```

启动成功后，服务将运行在 `http://localhost:8080`。

### 第五步：打开前端页面

直接在浏览器中打开项目根目录下的 `index.html` 文件即可。

---

## 接口说明

### 接口总览

| 接口路径 | HTTP方法 | Content-Type | 说明 |
| :--- | :--- | :--- | :--- |
| `/api/auth/register` | POST | application/json | 用户注册（v0.3新增） |
| `/api/auth/login` | POST | application/json | 用户登录（v0.3新增） |
| `/api/auth/verify` | GET | - | Token验证（v0.3新增） |
| `/api/chat/send` | POST | application/json | 基础对话（v0.1） |
| `/api/skill/file-parse` | POST | multipart/form-data | 文件解析（v0.2） |
| `/api/skill/dialog-clarify` | POST | application/x-www-form-urlencoded | 对话澄清（v0.2） |
| `/api/skill/link-generate` | POST | application/x-www-form-urlencoded | 链接生成（v0.2） |
| `/api/rag/vectors` | POST | application/json | 向量入库（v0.3） |
| `/api/rag/search` | GET | - | 向量检索（v0.3） |
| `/api/rag/stats` | GET | - | RAG统计（v0.3） |
| `/api/agent/chat` | POST | application/x-www-form-urlencoded | Agent对话（v0.3） |
| `/api/agent/tools` | GET | - | 工具列表（v0.3） |
| `/api/agent/logs` | GET | - | 工具日志（v0.3） |
| `/api/conversation` | POST | application/json | 新建会话（v0.4新增） |
| `/api/conversation` | GET | - | 获取会话列表（v0.4新增） |
| `/api/conversation/{id}` | GET | - | 获取会话详情（v0.4新增） |
| `/api/conversation/{id}/messages` | GET | - | 获取会话消息（v0.4新增） |
| `/api/conversation/{id}/title` | PUT | application/json | 修改会话标题（v0.4新增） |
| `/api/conversation/{id}` | DELETE | - | 删除会话（v0.4新增） |

> **认证说明**：除 `/api/auth/register` 和 `/api/auth/login` 外，所有接口需在请求头中携带 `Authorization: <token>`

---

### 1. 用户注册接口（v0.3新增）

**POST** `/api/auth/register`

#### 请求参数

| 参数名 | 类型 | 必填 | 说明 |
| :--- | :--- | :--- | :--- |
| username | String | 是 | 用户名（唯一） |
| password | String | 是 | 密码（至少6位） |
| confirmPassword | String | 是 | 确认密码 |
| nickname | String | 否 | 昵称（默认为用户名） |

#### 请求示例

```json
{
    "username": "testuser",
    "password": "123456",
    "confirmPassword": "123456",
    "nickname": "测试用户"
}
```

#### 响应示例

```json
{
    "code": 200,
    "message": "success",
    "data": {
        "id": 3,
        "username": "testuser",
        "nickname": "测试用户",
        "message": "注册成功，请登录"
    }
}
```

---

### 2. 用户登录接口（v0.3新增）

**POST** `/api/auth/login`

#### 请求参数

| 参数名 | 类型 | 必填 | 说明 |
| :--- | :--- | :--- | :--- |
| username | String | 是 | 用户名 |
| password | String | 是 | 密码 |

#### 请求示例

```json
{
    "username": "admin",
    "password": "admin"
}
```

#### 响应示例

```json
{
    "code": 200,
    "message": "success",
    "data": {
        "token": "eyJhbGciOiJIUzI1NiJ9...",
        "userId": 1,
        "username": "admin",
        "nickname": "管理员",
        "avatar": "",
        "expireTime": 1783549031000
    }
}
```

---

### 3. Token验证接口（v0.3新增）

**GET** `/api/auth/verify`

#### 请求参数

| 参数名 | 类型 | 必填 | 说明 |
| :--- | :--- | :--- | :--- |
| Authorization | String | 是 | 请求头中的JWT令牌 |

#### 请求示例

```bash
curl -X GET http://localhost:8080/api/auth/verify \
  -H "Authorization: eyJhbGciOiJIUzI1NiJ9..."
```

#### 响应示例

```json
{
    "code": 200,
    "message": "success",
    "data": {
        "userId": 1,
        "username": "admin",
        "expireTime": 1783549031000
    }
}
```

---

### 4. 基础对话接口（v0.1，v0.4更新）

**POST** `/api/chat/send`

#### 请求参数

| 参数名 | 类型 | 必填 | 说明 |
| :--- | :--- | :--- | :--- |
| userId | Long | 否 | 用户ID，首次发送可传null |
| message | String | 是 | 用户输入的问题文本 |
| sessionId | String | 否 | 会话ID，用于多轮对话 |
| conversationId | Long | 否 | 会话ID（v0.4新增），绑定到指定会话 |

#### 请求示例

```json
{
    "userId": 1,
    "message": "你好，帮我介绍一下Spring Boot框架",
    "conversationId": 1
}
```

#### 响应示例

```json
{
    "code": 200,
    "message": "success",
    "data": {
        "reply": "Spring Boot是由Pivotal团队提供的...",
        "userId": 1,
        "sessionId": "abc123",
        "conversationId": 1,
        "toolLogs": []
    }
}
```

---

### 2. 文件解析接口（v0.2）

**POST** `/api/skill/file-parse`

#### 请求参数

| 参数名 | 类型 | 必填 | 说明 |
| :--- | :--- | :--- | :--- |
| userId | Long | 否 | 用户ID |
| file | MultipartFile | 是 | 上传的文件（支持PDF/DOC/DOCX，最大10MB） |

#### 请求示例（curl）

```bash
curl -X POST http://localhost:8080/api/skill/file-parse \
  -F "userId=1" \
  -F "file=@example.pdf"
```

#### 响应示例

```json
{
    "code": 200,
    "message": "success",
    "data": {
        "result": "文件解析成功",
        "sceneType": null,
        "sceneName": null,
        "links": null,
        "document": {
            "id": 1,
            "fileName": "example.pdf",
            "fileType": "pdf",
            "fileSize": 102400,
            "content": "文档正文内容...",
            "summary": "文档摘要..."
        }
    }
}
```

---

### 3. 对话澄清接口（v0.2）

**POST** `/api/skill/dialog-clarify`

#### 请求参数

| 参数名 | 类型 | 必填 | 说明 |
| :--- | :--- | :--- | :--- |
| userId | Long | 否 | 用户ID |
| message | String | 是 | 用户输入的问题文本 |

#### 请求示例（curl）

```bash
curl -X POST http://localhost:8080/api/skill/dialog-clarify \
  -d "userId=1" \
  -d "message=我想请假"
```

---

### 4. 链接生成接口（v0.2）

**POST** `/api/skill/link-generate`

#### 请求参数

| 参数名 | 类型 | 必填 | 说明 |
| :--- | :--- | :--- | :--- |
| userId | Long | 否 | 用户ID |
| message | String | 是 | 用户输入的问题文本 |

#### 请求示例（curl）

```bash
curl -X POST http://localhost:8080/api/skill/link-generate \
  -d "userId=1" \
  -d "message=我要报销差旅费"
```

---

### 5. RAG向量入库接口（v0.3）

**POST** `/api/rag/vectors`

#### 请求参数

| 参数名 | 类型 | 必填 | 说明 |
| :--- | :--- | :--- | :--- |
| documentId | Long | 是 | 文档ID |
| content | String | 是 | 文档内容 |
| userId | Long | 否 | 用户ID |

#### 请求示例

```json
{
    "documentId": 1,
    "content": "文档内容...",
    "userId": 1
}
```

---

### 6. RAG向量检索接口（v0.3）

**GET** `/api/rag/search`

#### 请求参数

| 参数名 | 类型 | 必填 | 说明 |
| :--- | :--- | :--- | :--- |
| query | String | 是 | 查询文本 |
| topN | Integer | 否 | 返回数量（默认3） |
| userId | Long | 否 | 用户ID |

#### 请求示例

```bash
curl "http://localhost:8080/api/rag/search?query=招生政策&topN=3"
```

---

### 7. RAG统计接口（v0.3）

**GET** `/api/rag/stats`

#### 请求参数

| 参数名 | 类型 | 必填 | 说明 |
| :--- | :--- | :--- | :--- |
| userId | Long | 否 | 用户ID |

#### 响应示例

```json
{
    "code": 200,
    "message": "success",
    "data": {
        "totalVectors": 45,
        "totalDocuments": 5
    }
}
```

---

### 8. Agent对话接口（v0.3）

**POST** `/api/agent/chat`

#### 请求参数

| 参数名 | 类型 | 必填 | 说明 |
| :--- | :--- | :--- | :--- |
| userId | Long | 否 | 用户ID |
| message | String | 是 | 用户输入的问题文本 |
| sessionId | String | 否 | 会话ID |

#### 请求示例（curl）

```bash
curl -X POST http://localhost:8080/api/agent/chat \
  -d "userId=1" \
  -d "message=国庆节放假安排"
```

#### 响应示例

```json
{
    "code": 200,
    "message": "success",
    "data": {
        "reply": "根据学校放假通知，国庆节放假安排如下：...",
        "userId": 1,
        "sessionId": "abc123",
        "toolLogs": [
            {
                "toolName": "放假通知",
                "toolType": "mcp",
                "success": true,
                "error": null,
                "outputSummary": "获取到 3 条放假通知"
            },
            {
                "toolName": "RAG检索",
                "toolType": "retrieval",
                "success": true,
                "error": null,
                "outputSummary": "匹配到 2 条文档片段"
            }
        ]
    }
}
```

---

### 9. Agent工具列表接口（v0.3）

**GET** `/api/agent/tools`

#### 响应示例

```json
{
    "code": 200,
    "message": "success",
    "data": [
        {"name": "rag_search", "description": "RAG检索", "category": "retrieval"},
        {"name": "mcp_holiday", "description": "放假通知", "category": "mcp"},
        {"name": "mcp_reimburse", "description": "报销进度", "category": "mcp"},
        {"name": "mcp_course", "description": "选课余量", "category": "mcp"},
        {"name": "mcp_campus_card", "description": "校园卡通知", "category": "mcp"},
        {"name": "dialog_clarify", "description": "多轮澄清", "category": "skill"},
        {"name": "link_generate", "description": "办事链接", "category": "skill"}
    ]
}
```

---

### 10. Agent工具日志接口（v0.3）

**GET** `/api/agent/logs`

#### 请求参数

| 参数名 | 类型 | 必填 | 说明 |
| :--- | :--- | :--- | :--- |
| sessionId | String | 否 | 会话ID筛选 |
| userId | Long | 否 | 用户ID筛选 |
| toolName | String | 否 | 工具名称筛选 |
| limit | Integer | 否 | 返回数量（默认20） |

---

### 11. 新建会话接口（v0.4新增）

**POST** `/api/conversation`

#### 请求参数

无（自动关联当前登录用户）

#### 请求示例

```bash
curl -X POST http://localhost:8080/api/conversation \
  -H "Authorization: <token>" \
  -H "Content-Type: application/json"
```

#### 响应示例

```json
{
    "code": 200,
    "message": "success",
    "data": {
        "id": 1,
        "userId": 1,
        "title": "新对话",
        "sessionId": null,
        "createdAt": "2024-01-15T10:30:00",
        "updatedAt": "2024-01-15T10:30:00"
    }
}
```

---

### 12. 获取会话列表接口（v0.4新增）

**GET** `/api/conversation`

#### 请求参数

无（自动返回当前登录用户的所有会话）

#### 请求示例

```bash
curl -X GET http://localhost:8080/api/conversation \
  -H "Authorization: <token>"
```

#### 响应示例

```json
{
    "code": 200,
    "message": "success",
    "data": [
        {
            "id": 1,
            "userId": 1,
            "title": "关于Spring Boot的问题",
            "sessionId": "abc123",
            "createdAt": "2024-01-15T10:30:00",
            "updatedAt": "2024-01-15T11:00:00"
        },
        {
            "id": 2,
            "userId": 1,
            "title": "招生政策咨询",
            "sessionId": "def456",
            "createdAt": "2024-01-14T15:00:00",
            "updatedAt": "2024-01-14T15:30:00"
        }
    ]
}
```

---

### 13. 获取会话详情接口（v0.4新增）

**GET** `/api/conversation/{id}`

#### 请求参数

| 参数名 | 类型 | 必填 | 说明 |
| :--- | :--- | :--- | :--- |
| id | Long | 是 | 会话ID（路径参数） |

#### 请求示例

```bash
curl -X GET http://localhost:8080/api/conversation/1 \
  -H "Authorization: <token>"
```

---

### 14. 获取会话消息接口（v0.4新增）

**GET** `/api/conversation/{id}/messages`

#### 请求参数

| 参数名 | 类型 | 必填 | 说明 |
| :--- | :--- | :--- | :--- |
| id | Long | 是 | 会话ID（路径参数） |

#### 请求示例

```bash
curl -X GET http://localhost:8080/api/conversation/1/messages \
  -H "Authorization: <token>"
```

#### 响应示例

```json
{
    "code": 200,
    "message": "success",
    "data": [
        {
            "id": 1,
            "userId": 1,
            "conversationId": 1,
            "role": "user",
            "content": "你好，帮我介绍一下Spring Boot",
            "toolLogs": null,
            "createdAt": "2024-01-15T10:30:00"
        },
        {
            "id": 2,
            "userId": 1,
            "conversationId": 1,
            "role": "assistant",
            "content": "Spring Boot是由Pivotal团队提供的...",
            "toolLogs": null,
            "createdAt": "2024-01-15T10:30:05"
        }
    ]
}
```

---

### 15. 修改会话标题接口（v0.4新增）

**PUT** `/api/conversation/{id}/title`

#### 请求参数

| 参数名 | 类型 | 必填 | 说明 |
| :--- | :--- | :--- | :--- |
| id | Long | 是 | 会话ID（路径参数） |
| title | String | 是 | 新的会话标题 |

#### 请求示例

```bash
curl -X PUT http://localhost:8080/api/conversation/1/title \
  -H "Authorization: <token>" \
  -H "Content-Type: application/json" \
  -d '{"title": "Spring Boot学习笔记"}'
```

---

### 16. 删除会话接口（v0.4新增）

**DELETE** `/api/conversation/{id}`

#### 请求参数

| 参数名 | 类型 | 必填 | 说明 |
| :--- | :--- | :--- | :--- |
| id | Long | 是 | 会话ID（路径参数） |

#### 请求示例

```bash
curl -X DELETE http://localhost:8080/api/conversation/1 \
  -H "Authorization: <token>"
```

#### 说明

删除会话后，该会话的所有聊天记录将被级联删除。

---

## MCP模拟服务说明（v0.3）

### 服务概述

MCP（Model Context Protocol）模拟服务用于模拟教务/财务等第三方系统接口，提供以下4种服务：

| 服务名称 | 触发关键词 | 返回内容 |
| :--- | :--- | :--- |
| 放假通知 | 放假、假期、国庆、中秋、元旦 | 放假时间、时长、通知内容 |
| 报销进度 | 报销、费用、报销单 | 报销单号、类型、金额、状态 |
| 选课余量 | 选课、课程、上课 | 课程信息、剩余名额、状态 |
| 校园卡通知 | 校园卡、饭卡、充值、余额 | 余额、消费记录、充值记录 |

### MCP服务响应格式

```json
{
    "service": "holiday_notice",
    "serviceName": "放假通知查询",
    "notices": [
        {
            "title": "2024年国庆节放假安排",
            "date": "2024-10-01",
            "duration": "7天",
            "content": "放假调休安排...",
            "source": "学校办公室"
        }
    ],
    "count": 3,
    "queryTime": "2024-09-20 10:30:00"
}
```

---

## 新增数据表说明

### document_vector 表（向量分片表）

存储文档向量化后的向量数据。

| 字段名 | 类型 | 说明 |
| :--- | :--- | :--- |
| id | BIGINT | 主键，自增 |
| document_id | BIGINT | 关联文档ID |
| chunk_index | INT | 分片索引 |
| content | TEXT | 分片内容 |
| vector | TEXT | 向量数据（JSON数组格式） |
| user_id | BIGINT | 用户ID |
| created_at | DATETIME | 创建时间 |

### agent_task_log 表（工具执行日志表）

存储Agent工具调用记录。

| 字段名 | 类型 | 说明 |
| :--- | :--- | :--- |
| id | BIGINT | 主键，自增 |
| user_id | BIGINT | 用户ID |
| session_id | VARCHAR(64) | 会话ID |
| tool_name | VARCHAR(50) | 工具名称 |
| tool_type | VARCHAR(20) | 工具类型 |
| input | TEXT | 输入参数 |
| output | TEXT | 输出结果 |
| status | VARCHAR(20) | 执行状态 |
| error_message | TEXT | 错误信息 |
| created_at | DATETIME | 创建时间 |

---

## v0.4新增功能使用教程

### 1. 会话存档管理

**操作步骤**：

1. 在左侧边栏「📜 历史会话存档」区域查看所有会话
2. 点击「+ 新建对话」创建全新空白会话，清空当前聊天框
3. 点击任意会话条目切换到该会话，自动加载全部历史消息
4. 点击会话右侧「✏️」按钮重命名会话标题
5. 点击会话右侧「🗑️」按钮删除会话（同时删除所有聊天记录）

**自动生成标题**：
- 新会话第一条提问自动截取前15字作为标题
- 支持手动修改标题

**上下文连贯**：
- 切换会话后，自动加载该会话的历史消息作为上下文
- 上下文自动保留最近20轮，避免token超限
- 完整历史记录保存在数据库，不会丢失

### 2. 聊天记录持久化

**功能说明**：
- 所有消息（用户提问、AI回复、工具调用日志）自动存入MySQL数据库
- 重启后端服务、刷新浏览器页面，聊天记录不会丢失
- 登录后自动加载该用户的所有会话和聊天记录

**用户数据隔离**：
- A用户无法查看B用户的任何会话与聊天记录
- 所有会话接口自动验证用户权限

---

## v0.3新增功能使用教程

### 1. RAG知识库使用

**操作步骤**：

1. 在左侧边栏「📁 文件上传」区域上传PDF/Word文档
2. 文件上传后自动进行文本分片、向量化并入库
3. 上传过程中显示「正在向量化...」加载动画
4. 上传完成后，文档出现在「📚 知识库管理」列表中
5. 在聊天框中提问，Agent会自动检索相关文档片段

**示例**：
```
用户：学校的招生政策是什么？
AI：根据知识库中的文档《2024招生简章》，招生政策如下：...
```

### 2. Agent自动调度

**操作步骤**：

1. 在聊天框中输入任意问题
2. Agent自动识别意图，选择合适的工具执行
3. 工具执行结果合并后发送给AI生成最终回复
4. 在对话气泡底部展开「本次工具调用日志」查看详情

**支持的意图识别**：

| 意图 | 触发关键词 | 调用工具 |
| :--- | :--- | :--- |
| 招生咨询 | 招生、录取、报考 | RAG检索 + 办事链接 |
| 报销 | 报销、费用 | RAG检索 + 办事链接 + MCP报销进度 + 多轮澄清 |
| 选课 | 选课、课程 | RAG检索 + 办事链接 + MCP选课余量 |
| 请假 | 请假、休假 | RAG检索 + 办事链接 + MCP放假通知 + 多轮澄清 |
| 补助 | 补助、助学金 | RAG检索 + 办事链接 |
| 文档问答 | 文档、文件、内容 | RAG检索 |
| 放假查询 | 放假、假期、国庆 | MCP放假通知 + RAG检索 |
| 校园卡 | 校园卡、饭卡、余额 | MCP校园卡通知 + RAG检索 |
| 闲聊 | 你好、聊聊天 | 直接对话 |

### 3. 知识库管理

**操作步骤**：

1. 在左侧边栏点击「📚 知识库管理」展开面板
2. 查看文档统计（文档数、向量数）
3. 查看已上传文档列表及向量化状态
4. 点击文档右侧「×」删除单个文档
5. 点击「🗑️ 清空知识库」删除所有文档

### 4. 工具调用日志查看

**操作步骤**：

1. 在对话气泡中找到「本次工具调用日志」
2. 点击展开查看详细信息
3. 查看每个工具的名称、类型、执行状态和输出摘要
4. 点击收起隐藏日志

---

## 版本边界说明

### v0.3已实现功能

| 功能 | 状态 | 说明 |
| :--- | :--- | :--- |
| 基础对话 | ✅ | 调用通义千问API |
| 文件上传 | ✅ | 支持PDF/DOC/DOCX，解析内容和摘要 |
| 文件解析 | ✅ | 使用PDFBox和POI解析文档 |
| 多轮追问 | ✅ | 识别场景后自动追问补充信息 |
| 场景意图识别 | ✅ | 支持9种意图 |
| 办事链接生成 | ✅ | 根据场景匹配相关链接 |
| RAG向量知识库 | ✅ | 本地轻量向量生成，内存相似度检索 |
| Agent自动调度 | ✅ | ReAct智能体，多工具链调用 |
| MCP模拟服务 | ✅ | 放假通知、报销进度、选课余量、校园卡通知 |
| 知识库管理面板 | ✅ | 文档列表、向量统计、删除操作 |
| 工具调用日志 | ✅ | 对话气泡中展示工具调用记录 |

---

## 第四周完整验收自测清单

### 一、会话管理模块

| 序号 | 测试项 | 操作步骤 | 预期结果 |
| :--- | :--- | :--- | :--- |
| 1 | 新建会话 | 点击「+ 新建对话」按钮 | 创建新会话，聊天框清空 |
| 2 | 获取会话列表 | 调用 `/api/conversation` | 返回当前用户所有会话，按更新时间倒序 |
| 3 | 切换会话 | 点击会话列表中的会话 | 加载该会话所有历史消息 |
| 4 | 修改会话标题 | 点击「✏️」按钮修改标题 | 标题更新成功，列表同步刷新 |
| 5 | 删除会话 | 点击「🗑️」按钮删除会话 | 会话及所有消息被删除，页面清空 |
| 6 | 获取会话消息 | 调用 `/api/conversation/{id}/messages` | 返回该会话所有消息 |
| 7 | 自动生成标题 | 在新会话发送第一条消息 | 会话标题自动设置为消息前15字 |

### 二、聊天记录持久化模块

| 序号 | 测试项 | 操作步骤 | 预期结果 |
| :--- | :--- | :--- | :--- |
| 8 | 用户消息存档 | 发送一条消息 | 消息存入chat_history表 |
| 9 | AI回复存档 | AI回复后 | 回复内容存入chat_history表 |
| 10 | 工具调用日志存档 | 触发Agent工具调用 | 工具调用日志存入数据库 |
| 11 | 重启后端后消息保留 | 重启Spring Boot服务 | 登录后历史消息完整加载 |
| 12 | 刷新页面后会话保留 | 刷新浏览器页面 | 会话列表和消息完整加载 |

### 三、用户数据隔离模块

| 序号 | 测试项 | 操作步骤 | 预期结果 |
| :--- | :--- | :--- | :--- |
| 13 | 登录用户只能查看自己的会话 | 使用admin登录 | 只能看到admin的会话 |
| 14 | 登录用户只能查看自己的消息 | 使用student登录 | 只能看到student的消息 |
| 15 | 越权访问会话 | 使用admin token访问student的会话 | 返回403/无权限错误 |
| 16 | 越权访问消息 | 使用admin token访问student的消息 | 返回403/无权限错误 |

### 四、上下文连贯模块

| 序号 | 测试项 | 操作步骤 | 预期结果 |
| :--- | :--- | :--- | :--- |
| 17 | 切换会话上下文连贯 | 在会话A发送消息，切换到会话B，再切回A | 会话A的历史消息作为上下文 |
| 18 | 上下文截断 | 发送超过20轮消息 | 自动保留最近20轮作为上下文 |
| 19 | 数据库完整保留 | 发送超过20轮消息后查询数据库 | 所有消息完整保存在数据库 |

### 五、JWT鉴权模块

| 序号 | 测试项 | 操作步骤 | 预期结果 |
| :--- | :--- | :--- | :--- |
| 20 | 未登录访问会话接口 | 不携带token调用会话接口 | 返回401未授权 |
| 21 | 未登录访问消息接口 | 不携带token调用消息接口 | 返回401未授权 |
| 22 | 携带有效token访问 | 登录后携带token调用接口 | 正常返回数据 |

---

## 第三周完整验收自测清单

### 一、RAG向量知识库模块

| 序号 | 测试项 | 操作步骤 | 预期结果 |
| :--- | :--- | :--- | :--- |
| 1 | 文件上传自动向量化 | 上传PDF/Word文档 | 文件解析成功，显示向量化加载动画 |
| 2 | 向量入库验证 | 调用 `/api/rag/stats` | 返回向量数量 > 0 |
| 3 | 文档向量查询 | 调用 `/api/rag/vectors/document/{id}` | 返回该文档的所有向量分片 |
| 4 | 向量检索 | 调用 `/api/rag/search?query=关键词` | 返回匹配的文档片段 |
| 5 | RAG增强问答 | 上传文档后提问相关问题 | AI回复包含文档内容 |

### 二、Agent自动调度模块

| 序号 | 测试项 | 操作步骤 | 预期结果 |
| :--- | :--- | :--- | :--- |
| 6 | 放假查询意图识别 | 输入「国庆节放假安排」 | 自动调用MCP放假通知 + RAG检索 |
| 7 | 报销查询意图识别 | 输入「我的报销进度」 | 自动调用MCP报销进度 + 办事链接 + RAG检索 |
| 8 | 选课查询意图识别 | 输入「人工智能导论还有名额吗」 | 自动调用MCP选课余量 + 办事链接 + RAG检索 |
| 9 | 校园卡查询意图识别 | 输入「校园卡余额」 | 自动调用MCP校园卡通知 + RAG检索 |
| 10 | 文档问答意图识别 | 输入「根据文档内容回答...」 | 自动调用RAG检索 |
| 11 | 工具调用日志记录 | 发送任意问题 | 对话气泡显示工具调用日志面板 |
| 12 | 多工具链调用 | 输入复杂问题 | Agent依次调用多个工具，合并结果 |

### 三、MCP模拟服务模块

| 序号 | 测试项 | 操作步骤 | 预期结果 |
| :--- | :--- | :--- | :--- |
| 13 | 放假通知接口 | 通过Agent查询放假信息 | 返回模拟的放假通知数据 |
| 14 | 报销进度接口 | 通过Agent查询报销进度 | 返回模拟的报销记录 |
| 15 | 选课余量接口 | 通过Agent查询课程余量 | 返回模拟的课程信息 |
| 16 | 校园卡通知接口 | 通过Agent查询校园卡 | 返回模拟的校园卡信息和通知 |

### 四、前端改造模块

| 序号 | 测试项 | 操作步骤 | 预期结果 |
| :--- | :--- | :--- | :--- |
| 17 | 知识库管理面板 | 展开左侧「知识库管理」 | 显示文档统计和文档列表 |
| 18 | 文档删除 | 点击文档右侧「×」 | 文档被删除，列表更新 |
| 19 | 清空知识库 | 点击「清空知识库」按钮 | 所有文档被删除，统计归零 |
| 20 | 工具调用日志折叠 | 点击「本次工具调用日志」 | 展开/收起工具调用记录 |
| 21 | 向量化加载动画 | 上传文件 | 显示「正在向量化...」旋转动画 |
| 22 | 办事链接动态渲染 | 通过Agent查询办事链接 | 链接卡片由Agent动态返回 |

### 五、接口异常捕获

| 序号 | 测试项 | 操作步骤 | 预期结果 |
| :--- | :--- | :--- | :--- |
| 23 | 参数缺失 | 调用接口不传必填参数 | 返回400错误，提示参数缺失 |
| 24 | 文件格式错误 | 上传非PDF/DOC/DOCX文件 | 返回400错误，提示不支持的文件类型 |
| 25 | 文件过大 | 上传超过10MB的文件 | 返回400错误，提示文件过大 |
| 26 | 数据库连接失败 | 断开数据库后启动服务 | 返回500错误，提示连接失败 |
| 27 | API Key错误 | 使用无效的API Key | 返回错误提示，服务不崩溃 |

---

## 项目结构

```
WayMind/
├── index.html                            # 前端聊天页面（v0.3更新）
├── pom.xml                               # Maven依赖配置
├── README.md                             # 项目说明文档
└── src/main/
    ├── java/com/studymate/
    │   ├── Application.java              # 启动类
    │   ├── auth/
    │   │   ├── JwtUtil.java             # JWT工具类（v0.3新增）
    │   │   ├── controller/
    │   │   │   └── AuthController.java  # 认证接口控制器（v0.3新增）
    │   │   └── interceptor/
    │   │       └── AuthInterceptor.java # 全局拦截器（v0.3新增）
    │   ├── config/
    │   │   ├── CorsConfig.java           # CORS跨域配置
    │   │   └── DatabaseMigrationRunner.java  # 数据库迁移（v0.3新增）
    │   ├── controller/
│   │   ├── ChatController.java       # 基础对话控制器（v0.4改造支持会话）
│   │   ├── SkillController.java      # Skill接口控制器
│   │   └── ConversationController.java # 会话管理控制器（v0.4新增）
    │   ├── dto/
    │   │   ├── ApiResponse.java
    │   │   ├── ChatRequest.java
    │   │   ├── ChatResponse.java         # 新增toolLogs字段
    │   │   └── SkillResponse.java
    │   ├── entity/
│   │   ├── ChatHistory.java              # 聊天记录（v0.4新增conversation_id、role字段）
│   │   ├── Conversation.java             # 会话实体（v0.4新增）
│   │   ├── User.java
│   │   ├── Document.java
│   │   └── LinkMap.java
    │   ├── exception/
    │   │   └── GlobalExceptionHandler.java
    │   ├── mapper/
│   │   ├── ChatHistoryMapper.java         # 聊天记录（v0.4新增按会话查询方法）
│   │   ├── ConversationMapper.java        # 会话Mapper（v0.4新增）
│   │   ├── UserMapper.java
│   │   ├── DocumentMapper.java
│   │   └── LinkMapMapper.java
    │   ├── mcp/
    │   │   └── McpCampusService.java     # MCP模拟服务（v0.3新增）
    │   ├── rag/
    │   │   ├── controller/
    │   │   │   └── DocumentVectorController.java
    │   │   ├── entity/
    │   │   │   └── DocumentVector.java
    │   │   ├── mapper/
    │   │   │   └── DocumentVectorMapper.java
    │   │   ├── service/
    │   │   │   ├── DocumentVectorService.java
    │   │   │   ├── VectorSearchService.java
    │   │   │   └── impl/
    │   │   │       └── DocumentVectorServiceImpl.java
    │   │   └── util/
    │   │       ├── TextChunkUtil.java
    │   │       └── VectorEmbeddingUtil.java
    │   ├── agent/
    │   │   ├── controller/
    │   │   │   └── AgentController.java
    │   │   ├── entity/
    │   │   │   └── AgentTaskLog.java
    │   │   ├── mapper/
    │   │   │   └── AgentTaskLogMapper.java
    │   │   ├── registry/
    │   │   │   └── ToolRegistry.java
    │   │   └── service/
    │   │       ├── AgentCoreService.java
    │   │       └── impl/
    │   │           └── AgentCoreServiceImpl.java
    │   ├── service/
│   │   ├── ChatService.java
│   │   ├── impl/ChatServiceImpl.java       # 改造支持会话绑定和消息存档（v0.4）
│   │   ├── ConversationService.java        # 会话服务（v0.4新增）
│   │   ├── impl/
│   │   │   ├── ConversationServiceImpl.java # 会话服务实现（v0.4新增）
│   │   │   ├── FileParseServiceImpl.java
│   │   │   ├── DialogClarifyServiceImpl.java
│   │   │   └── LinkGenerateServiceImpl.java
│   │   ├── FileParseService.java
│   │   ├── DialogClarifyService.java
│   │   └── LinkGenerateService.java
    │   └── util/
    │       ├── QianWenClient.java
    │       ├── DocumentParserUtil.java
    │       └── IntentRecognizerUtil.java
    └── resources/
        ├── application.yml               # 应用配置
        └── schema.sql                    # 建表SQL（v0.4新增conversation表，改造chat_history表）
```

---

## 技术栈

| 组件 | 版本 | 说明 |
| :--- | :--- | :--- |
| Spring Boot | 3.2.5 | 后端框架 |
| MyBatis-Plus | 3.5.5 | ORM框架 |
| MySQL | 8.0+ | 数据库 |
| Vue.js | 3.x | 前端框架 |
| Apache HttpClient5 | 5.2.1 | HTTP请求工具 |
| Apache PDFBox | 3.0.2 | PDF解析 |
| Apache POI | 5.2.5 | Word解析 |
| 通义千问 | qwen-turbo | AI大模型 |

---

## License

MIT License